## Environment

Las variables se definen en *deployment.yml*, dentro de `containers:`, del siguiente modo:

```yaml
containers:
        - name: story-app
          image: warckor/k8s_project:story2
          env:
            - name: STORY_FOLDER
              value: 'story'
          volumeMounts:
            - mountPath: /app/story
              name: story-volume
          resources:
            limits:
              memory: "128Mi"
              cpu: "500m"
```


## Config Maps

Los *Config Maps* son unos archivos de configuración que permiten definir variables de entorno sin tener que incoporarlos a nuestro fichero de configuración de *Deployment*.

En estos ficheros se definen distintas variables *clave-valor* para que luego, desde los otros ficheros de configuración donde se necesite, podamos hacer uso de la clave para obtener el valor.

Archivo de configuración *Config Map* de ejemplo:

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: cm-env
data:
  folder: 'story'
```

Después se incluiría en el fichero de configuración de *Deployment* en el apartando `env:` del siguiente modo:

```yaml
spec:
      containers:
        - name: story-app
          image: warckor/k8s_project:story2
          env:
            - name: STORY_FOLDER
              valueFrom:
                configMapKeyRef:
                  name: cm-env
                  key: folder
          volumeMounts:
            - mountPath: /app/story
              name: story-volume
          resources:
            limits:
              memory: "128Mi"
              cpu: "500m"
      volumes:
        - name: story-volume
          persistentVolumeClaim:
            claimName: host-pvc
```











#kubernetes #k8s #declarative #env #configmap 