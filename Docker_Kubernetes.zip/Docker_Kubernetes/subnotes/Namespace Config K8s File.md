Existen dos opciones para poder generar nuestro *Namespace*. 

1. A través del fichero de configuración `YAML`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
	name: dev
```

```shell
kubectl create -f namespace-dev.yml
```

2. A través de la consola con el siguiente comando:

```shell
kubectl create namespace dev
```

Para poder cambiar de `namespace`, podemos ejecutar el siguiente comando en la consola para cambiar la configuración de nuestro kubectl:

```shell
kubectl config set-context $(kubectl config current-context) --namespace=dev
```







#kubernetes #k8s #declarative #namespace
