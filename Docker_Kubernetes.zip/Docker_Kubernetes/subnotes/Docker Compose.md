Herramienta utilizada para la orquestación de varios contenedores complementados entre sí.

### 1. Configuración de fichero: [[Compose Files]]

### 2. Arranque y parada de servicios: [[Up And Down Services]]








**Index:** [[Docker]]

#docker #docker-compose 