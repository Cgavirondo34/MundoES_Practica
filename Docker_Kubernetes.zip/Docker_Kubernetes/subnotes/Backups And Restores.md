# Backups

Tenemos **tres fuentes** de las que realizar backups:

* *Resource Configuration*: La fuente de todos los ficheros de configuración de los componentes desplegados.

* *ETCD*: Donde se encuentran todos los datos de todo lo realizado en los componentes o datos requeridos para los componentes.

* *Persistent Volumes*: Los volumenes persistentes que se hayan podido generar para los *deployments*.

## Resource Configuration Backup

Para este backup, una de las opciones es tener toda la configuración en ficheros de configuración que pueden almacenarse como backup comodamente (GitHub, Azure, AWS, ...).

La otra opción es acceder directamente al **kube-apiserver** del *master node*, donde se encuentra toda la información de configuración de cada componente que tengamos desplegado en el *cluster*.

Por ejemplo, uno de los comandos que se pueden ejecutar para la tarea de backup, para poder almacenar la configuración de todos los componentes del *cluster*, puede ser:

```shell
kubectl get all --all-namespaces -o yaml > all-deploy-services-yaml
```

Existen muchas más opciones, como aplicaciones de terceros. Un ejemplo de aplicación sería **VELERO**, más conocido como **ARK**.

## ETCD Backup

Los backup de **ETCD** almacena el *estado de los clusters* y la *información de los cluster*. Los **ETCD** se pueden encontrar en los *master nodes* y la configuración de la carpeta donde se almacena esta información se encuentra en el archivo de configuración `etc.service` en la opción `--data-dir=/var/lib/etcd`. 

**ETCD** viene ya con una solución de snapshot incluida que genera un dump de base de datos con toda la información contenida en **ETCD**, la cual puede usarse con el comando:

```shell
ETCDTL_API=3 etcdctl snashot save snapshot.db
```

Para restaurar este snapshot, lo que hacemos es:

1. Detener el **kube-apiserver** con el comando:

```shell
service kube-apiserver stop
```

2. Ejecutar el comando de **ETCD** para restaurar el snapshot, guardandolo en otra ruta para que no surgan problemas al pisar la configuración actual, con el comando:

```shell
ETCDCTL_API=3 etcdctl snapshot restore snapshot.db --data-dir /var/lib/etcd-from-backup
```

 3. Cambiamos la ruta de almacenamiento de datos de **ETCD** para que apunte a la nueva ruta donde hemos restaurado los datos. Esto lo hacemos en el fichero de configuración `etcd.service` en la opción `--data-dir=/var/lib/etcd-from-backup`.

4. Después, restauramos el  daemon y los servicios con los comandos:

```shell
systemctl daemon-reload
service etcd restart
```

5. Por último, volvemos a levantar los servicios de **kube-apiserver**:

```shell
service kube-apiserver start
```







#kubernetes #k8s #backups #restores