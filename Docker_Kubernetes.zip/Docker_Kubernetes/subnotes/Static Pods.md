Los *Pods estaticos* son aquellos que se han desplegado directamente desde el **kubelet**. La ruta donde se deben almacenar los archivos de configuración del *Pod* es: `/etc/kubernetes/manifests`.

Esta ruta está definida también para los *Pods* desplegados con normalidad, es el lugar donde el **kubelet** tiene almacenado la información del *Pod*, de modo que, si hay que reiniciarlo se comprueba la configuración aquí y, si hay que eliminarlo, se elimina este fichero para hacerlo.

Esta ruta puede ser modificada desde el archivo de configuración del kubelet, el cual se llama `kubelet.service`, en la opción `--pod-manifest-path=/etc/kubernetes/manifests`.

Otro modo de aplicar la configuración sería meter como parámetro en el archivo `-- config=kubeconfig.yaml`, donde se le pasa la ruta a un *YAML* con la configuración, donde se encontraría:

```yaml
# kubeconfig.yaml
staticPodPath: /etc/kubernetes/manifest
```







#kubernetes #k8s #pod #config 