Esta configuración esta pensada para poder definir en qué *nodo* deben desplegarse los *Pods* según una serie de criterios definidos.

Podemos definir en la configuración del *Pod* en qué tipo de *nodos* debería de levantarse, incluyendo el tag `nodeSelector` del siguiente modo:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: myapp-prod
spec:
	containers:
		- name: data-processor
		  image: data-processor
	nodeSelector:
		size: Large
```

Las claves-valor definidas en el tag, son definiciones o `labels` que se han creado dentro de las configuraciones de los *nodos*, de modo que `size: Large` es un identificador incluido en el *Pod* para filtrar los *nodos* donde puede desplegarse. 

Para incluir el `label` en el *nodo*, tenemos el siguiente comando:

```shell
kubectl label node <node-name> <label-key>=<label-value>

# EJEMPLO
kubectl label node node-1 size=Large
```

Este tipo de configuración tiene limitaciones puesto que no se pueden construir condicionales en el *Pod* para seleccionar, por ejemplo, `size=Large OR size=Medium`. Tampoco se puede implementar el criterio de negación como `size!=Small`.

Para esto tenemos otro recurso llamado **Node affinity**.





#kubernetes #k8s #node #selectors #config #pod 