Existen diferentes drivers de configuración de volumenes en **Kubernetes** en función al sistema que se está utilizando: Azure, AWS, Nexus, ... .

Los tres principales que podemos utilizar de modo local son: CSI, emptyDir y hostPath. Todos estos se comportan dentro del contenedor del mismo modo, como un volumen de almacenamiento, pero tienen distintas características en cuanto a su comportamiento fuera del contenedor.

La definición de *volume* se realiza en los `spec` del *Pod*, en el fichero de configuración `deployment.yml`.

## emptyDir

Este tipo de volumen genera un nuevo directorio vacío cada vez que se inicia el *Pod* y mantiente este directorio vivo y con datos siempre que el *Pod* permanezca levantado.

```yaml
spec:
	containers:
		- name: story
		- image: warckor/k8s_project:story
		- volumeMounts:
			- mountPath: /app/story    # Ruta en el contenedor
			  name: story-volume
	volumes:
		- name: story-volume
		  emptyDir: {}                 # Driver
```

Si los contenendores dentro del *Pod* se eliminan, los datos dentro del directorio **se mantienen**. Únicamente se eliminan los datos del directorio cuando el *Pod* se elimina por completo.

Si existen varias replicas del mismo *Pod*, cada replica tiene **su propio almacenamiento y estos no comparten** la información entre sí.

## hostPath

Este tipo de volumen nos permite compartir los recursos de almacenamiento con todos los *Pods* que se encuentren **dentro del mismo host**. Todo el almacenamiento podrá ser visible en todos los *Pods*.

En la configuración no se tiene que especificar solo el `mountPath`, además se tiene que especificar la ruta local donde se va vincular el almacenamiento como con los **Bind Volumes** de *Docker*.

```yaml
spec:
	containers:
		- name: story
		- image: warckor/k8s_project:story
		- volumeMounts:
			- mountPath: /app/story    # Ruta en el contenedor
			  name: story-volume
	volumes:
		- name: story-volume
          hostPath:
			path: /data                #Ruta de la máquina local (en local Minikube)
            type: DirectoryOrCreate  
```

El campo `type` define el comportamiento de *Kubernetes* en caso de no existir la ruta especificada. En este caso, con el valor `DirectoryOrCreate` se especifica que el volumen definido debe comportarse como **directorio** y que, en caso de no existir, **debe crearse**.

## CSI

Este driver fue pensado para un uso más flexible entre los distintos entornos y clouds disponibles. Es como un driver global con el que los cloud más grandes ya tienen sus entornos preparados para poder utilizarlo.

## Persistent Volumes

Estos volumenes, como su nombre indica, son persistentes. A diferencia de los otros, estos volumenes **no se pierden** cuando los *Pods* se finalizan.

Son independientes de los *Pod* y de los *Nodes* y, como administrador, permite una configuración plena del volumen. Se puede definir su configuración en una ocasión y aprovecharlo en multiples *Pods* (como con un *filesystem*).

Dentro del *Pod*, se configura un **Persistent Volume Claim (PVC)** que es el que reclama una parte de este volumen.

### Definición de fichero PV

```yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: host-pv
spec:
  capacity:
    storage: 1Gi
  storageClassName: standard
  volumeMode: Filesystem
  hostPath:
    path: /data
    type: DirectoryOrCreate
  accessModes:
    - ReadWriteOnce
```

### Definición de fichero PVC

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: host-pvc
spec:
  volumeName: host-pv
  storageClassName: standard
  resources:
    requests:
      storage: 500Mi
  volumeMode: Filesystem
  accessModes:
    - ReadWriteOnce
```

### Definición en deployment

```yaml
volumes:
	- name: story-volume
	  persistentVolumeClaim:
		claimName: host-pvc
```








#kubernetes #k8s #declarative #volumes 