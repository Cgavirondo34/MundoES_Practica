```yaml
apiVersion: v1
kind: Pod
metadata:
	name: my-app
	labels:
		app: my-app
		tier: nginx
spec:
	containers:
		- name: my-container
		  image: warckor/my-app
```


## Namespace

Se puede definir el cluster donde queremos definir nuestro *Pod* incluyendo el parámetro `namespace:` dentro del `metadata:`. Quedaría del siguiente modo:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: my-app
	namespace: develop
	labels:
		app: my-app
		tier: nginx
spec:
	containers:
		- name: my-container
		  image: warckor/my-app
```













#kubernetes #k8s #declarative #pod #config  