Se pueden definir variables de entorno en un *pod* través del fichero de configuración:

## Plain Key Value:
Se mete la variable de entorno directamente en el archivo de configuración.

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: myapp
spec:
	containers:
	- name: myapp
	  image: myapp
	  ports:
	  - containerPort: 8080
	  env:
	  - name: APP_COLOR
	    value: blue
```

## ConfigMap:
Se mete la variable de entorno a través de un archivo de configuración llamado *ConfigMap*.

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: myapp
spec:
	containers:
	- name: myapp
	  image: myapp
	  ports:
	  - containerPort: 8080
	  env:
	  - name: APP_COLOR
	    valueFrom:
		    configMapKeyRef:
			    name: myapp-config
			    key: APP_COLOR
```

**ConfigMaps: [[ConfigMaps]]**

## Secrets:
Se mete la variable de entorno a través de un archivo de configuración llamado *Secret*. Este archivo es semejante al *ConfigMap* pero tiene sus datos encriptados por seguridad.

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: myapp
spec:
	containers:
	- name: myapp
	  image: myapp
	  ports:
	  - containerPort: 8080
	  env:
	  - name: APP_COLOR
	    valueFrom:
		    secretKeyRef:
```

**Secrets**: [[Secrets]]





#kubernetes #k8s #env #config 