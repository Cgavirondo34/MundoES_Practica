Cuando realizamos la instalación de *Kubernetes* en un *cluster*, instalamos una versión del mismo que podemos mirar a través del comando `kubectl get nodes`.

Existen versiones **LTS**, donde la release es estable y se mantendrá como versión principal durante un lapso largo de tiempo y luego existen las versiones **alpha** y **beta**.

No todos los componentes tienen la misma versión, puesto que el **ETCD CLUSTER** y el **CoreDNS** tienen cada uno su propia versión.












#kubernetes #k8s #upgrade #versions