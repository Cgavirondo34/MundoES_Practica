Cuando se despliegan los *Pods*, pueden no existir recursos suficientes en ninguno de los *nodos*, por lo que quedaría en estado pendiente hasta que existieran recursos suficientes porque se ha cerrado un *Pod* o porque se han habilitado mayores recursos en los *nodos*.

Los recursos que se pueden definir en un *nodo* son: **CPU**, **Memoria**, **Disco**.

En los *Pods* se definen los recursos mínimos que requeriran los contenedores y el límite de recursos:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: simple-webapp-color
	labels:
		name: simple-webapp-color
spec:
	containers:
		- name: simple-webapp-color
		  image: simple-webapp-color
		  ports:
			  - containerPort: 8080
		  resources:
			  requests:
				  memory: "1Gi"
				  cpu: 1
			  limits:
				  memory: "2Gi"
				  cpu: 2
```

Cuando un *Pod* trata de exceder los límites definidos, **no permite** consumir más *CPU* de la definida y **permite** exceder durante un lapso de tiempo el consumo de *Memoria* hasta el límite del nodo. Si este límite se excede más tiempo del establecido por *Kubernetes*, el *Pod* se finaliza.

Para definir los recursos por defecto de un *Pod*, se puede definir un **LimitRange** en el *namespace* donde despleguemos la siguiente configuración:

```yaml
apiVersion: v1
kind: LimitRange
metadata:
	name: mem-limit-range
spec:
	limits:
		- default:
			memory:512Mi
			cpu: 1
		defaultRequest:
			memory: 256Mi
			cpu: 0.5
		type: Container
```




#kubernetes #k8s #pod #containers #resource