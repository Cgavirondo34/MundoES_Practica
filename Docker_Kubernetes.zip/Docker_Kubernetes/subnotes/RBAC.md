Para poder generar los roles, tenemos que crear un *role object*, y para ello realizamos un `YAML` con la siguiente configuración:

```YAML
# developer-role.yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
	name: developer
rules:
- apiGroups: [""]
  resources: ["pods"]
  resourcesNames: ["myapp"]
  verbs: ["list", "get", "create", "update", "delete"]
- apiGroups: [""]
  resources: ["ConfigMap"]
  verbs: ["create"]
```

Creamos el nuevo rol con el comando:

```shell
kubectl create -f developer-role.yaml
```

Ahora hay que vincular al usuario a ese rol y para ello vamos a crear un nuevo *RoleBinding objetct*:

```yaml
# devuser-developer-binding.yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
	name: devuser-developer-binding
subjects:
- kind: User
  name: dev-user
  apiGroup: rbac.authorization.k8s.io
roleRef:
	kind: Role
	name: developer
	apiGroup: rbac.authorization.k8s.io
```

Creamos el nuevo *RoleBinding* con el comando:

```shell
kubectl create -f devuser-developer-binding.yaml
```

Con este ejemplo facilitamos el acceso de los *pods* y de los *ConfigMaps* al usuario **en el namespace por defecto**. Si queremos especificar un *namespace*, lo incluimos dentro de `metadata:` con el campo `namespace:` dentro del archivo de configuración del *Rol*.

Para comprobar los **permisos disponibles como usuario**, lo que podemos hacer es una consulta con el siguiente comando:

```shell
# Consultar si puedo crear nuevos deployments
kubectl auth can-i create deployments

# Consultar si puedo eliminar nodos
kubectl auth can-i delete nodes

# Consultar como ADMIN si otro usuario tiene permisos para crear pods
kubectl auth can-i create pods --as dev-user

# Cosnultar como ADMIN si otro usuario tiene permisos para crear pods en otro NAMESPACE
kubectl auth can-i create pods --as dev-user --namespace test
```

Se puede limitar más todavía el acceso de usuario a unos recursos específicos, para ello en el archivo de configuración del *Role Object* incluiríamos el campo `resourceNames:` del siguiente modo:

```YAML
# developer-role.yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
	name: developer
rules:
- apiGroups: [""]
  resources: ["pods"]
  verbs: ["list", "get", "create", "update", "delete"]
  resourceNames: ["blue", "orange"]
- apiGroups: [""]
  resources: ["ConfigMap"]
  verbs: ["create"]
```

## Cluster Roles
El rol de los *cluster* tiene que definirse de otro modo, puesto que no pueden entrar por la misma definición por la que entran los *namespace*. Por ejemplo, para definir los permisos en un *nodo* o de un *volumen*, tenemos que hacerlo a través de los *cluster roles*.

Podemos ver el listado de recursos de *namespace* y los que no lo son con los comandos:

```shell
# Recursos de namepspace
kubectl api-resources --namespaced=true

# Recursos que no son de namespace
kubectl api-resources --namespaced=false
```

Para ello tenemos que definir dos tipos de objetos: **clusterroles** y **clusterrolebindings**.

### ClusterRoles & ClusterRoleBindings
Un archivo de configuración para el recurso *ClusterRole* sería de este modo:

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
	name: cluster-administrator
rules:
- apiGroups: [""]
  resources: ["nodes"]
  verbs: ["list", "get", "create", "delete"]
```

Una vez tenemos creado el rol, tenemos que vincularlo a un tipo de usuario con el recurso *CluserRoleBinding*:

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
	name: cluster-admin-role-binding
subjects:
- kind: User
  name: cluster-admin
  apiGroup: rbac.authorization.k8s.io
roleRef:
	kind: ClusterRole
	name: cluster-administrator
	apiGroup: rbac.authorization.k8s.io
```













#kubernetes #k8s #security #authorization #RBAC