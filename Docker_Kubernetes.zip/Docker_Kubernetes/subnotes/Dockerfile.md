Un **Dockerfile** es un fichero de configuración de una imagen que queremos preparar con la configuración desarrollada dentro para el tipo de aplicación que queremos desplegar.

Es importante el _orden de los comandos_, puesto que una vez se ha ejecutado una primera vez, todos los pasos _quedan cacheados_, por lo que si se ejecuta una segunda, tercera, cuarta... vez lo que se va a ejecutar es todo aquello que haya sufrido algún tipo de modificación.

## Imagen de plantilla
Para poder generar el **Dockerfile**, lo primero que tenemos que insertar es de qué imagen base se va a componer:

```Shell
FROM ubuntu:latest
# Imagen de Ubuntu, la última versión.
```

Estas imagenes las podemos obtener de [Docker Hub](https://hub.docker.com/).

## Directorio de trabajo
Se puede definir la _ruta donde se va a trabajar ejecutando comandos_, que generalmete será la ruta donde se encontrará nuestra aplicación:

```shell
WORKDIR /app
```

## Ejecutar comandos dentro de la imagen
Tanto si es _Nodejs_, como si es _Django_, como si es _Ruby on Rails_ o _Python_, generalmente tendremos un fichero que realiza la instalación de las librerías y dependencias que requiere nuestra aplicación.

También puede que necesitemos instalar algunos paquetes, dependencias o actualizaciones y, para ello, podemos ejecutar comandos en el proceso de construcción de nuestra aplicación.

Para ello, podemos incluir las siguientes instrucciones con el comando:

```shell
RUN python -m requirements.txt
# Instala todos los módulos que hayamos definido en requirements

RUN npm install
# Instala todos los módulos definidos en package.json

RUN bundle install
# Instala todas las gemas de Ruby definidas en Gemfile

RUN apt update && apt upgrade -y
# Actualizamos el sistema operativo en el caso de ser entorno Debian
```

## Copiar ficheros
Para poder ejecutar lo anterior, tendremos que disponer en nuestra construcción previamente de _los ficheros con la definición de los módulos_ que requiere nuestro proyecto. 

Incluimos el siguiente comando:
```shell
# COPY <PATH_ORIGEN> <PATH_DESTINO
COPY package.json /app

# Si hemos definido previamente nuestro WORKDIR
COPY package.json .

# Si queremos copiar directamente toda nuestra aplicación
COPY . .
```

## Exponer puertos
Para las aplicaciones con las que se pueden trabajar a través de servicios online, como webs, APIS u otro tipo de aplicativos que requieren de comunicación _a través de un puerto_, se puede habillitar la comunicación a través del mismo.

Para ello, usamos el comando:

```shell
EXPOSE 3000
# Exponemos el puerto 3000, el que usa por ejemplo Nodejs para React
```

## Ejecutar comandos en el contenedor
Podemos configurar comandos que _se ejecutaran una vez que levantemos un contenedor_. Por ejemplo, cuando queremos levantar el servidor para un servicio web en Nodejs o Django.

La instrucción requiere de un *array* separando cada parte del comando con comas y dobles comillas:

```shell
CMD ["npm", "start"]
# Iniciar el servidor de Nodejs

CMD ["manage.py", "runserver"]
# Iniciar el servidor de Django
```

## Apendicar comandos en el contenedor
Podemos configurar comandos que *van a encabezar otros comandos* que luego puedan ser incluidos desde *consola*. Para hacer esto, tendremos que usar la siguiente entrada en nuestro **Dockerfile**:

```shell
ENTRYPOINT ["npm"]
```

De este modo, cuando arranquemos el *contenedor*, podremos incorporar al final de nuestro comando lo que puede enlazarse con `npm` como:

```shell
docker run -it -v /app/node_modules -p 3001:3001 --name node_test node:test install
# arrancará el contenedor con "npm install"

docker run -it -v /app/node_modules -p 3001:3001 --name node_test node:test init
# arrancará el cntenedor con "npm init"
```

Esto es solo un ejemplo, se puede hacer con cualquier comando y cualquier aplicación. Es un modo de garantizar la ejecución de unos comandos específicos.

## Ejemplo de Dockerfile
Ejemplo de una aplicación de `React.js`:

```shell
FROM node:18

WORKDIR /app

COPY package.json .

RUN npm install

COPY . .

EXPOSE 3000

ENTRYPOINT["npm"]

CMD ["npm", "start"]
```

## .dockerignore
Al igual que **Git**, disponemos también de un fichero para evitar copiar a la imagen ciertas carpetas o archivos que no queramos pasar (contraseñas, .git, .env, ...). Para ello, dentro de la carpeta donde tenemos el proyecto que queremos dockerizar, incluimos el fichero _.dockerignore_.






#docker #dockerfile


