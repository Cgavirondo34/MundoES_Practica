Archivo de configuración que nos permite definir variables de entorno desde un archivo independiente al *pod* en forma de **clave-valor**.

Puede definirse de manera *declarativa*:

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
	name: app-config
data:
	APP_COLOR: blue
	APP_MODE: prod
```

También, puede definirse de manera *imperativa*:

```shell
# Estructura
kubectl create configmap <config-name> --from-literal=<key>=<value>

# Ejemplo
kubectl create configmap app-config --from-literal=APP_COLOR=blue
```

Del modo *imperativo* también existe la posibilidad de pasarle un fichero con la configuración:

```shell
# Estructura
kubectl create configmap <config-name> --from-file=<path-to-file>

# Ejemplo
kubectl create configmap app-config --from-file=app_config.properties
```

Para definir nuestro fichero de configuración *configMap* en el *pod* tenemos que incorporarlo del siguiente modo:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: simple-webapp-color
	labels:
		name: simple-webapp-color
spec:
	containers:
	- name: simple-webapp-color
	  image: simple-webapp-color
	  ports:
	  - containerPort: 8080
      envFrom:
      - configMapRef:
	      name: app-config
```












#kubernetes #k8s #env #config #configmap 