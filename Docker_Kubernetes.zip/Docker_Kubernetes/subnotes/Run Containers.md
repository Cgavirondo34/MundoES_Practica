Para poder lanzar un nuevo _contenedor_ basado en una de las _imagenes_ que hayamos creado a través de un **Dockerfile** o descargado desde _Docker Hub_, podremos ejecutar el siguiente comando:

```shell
docker run <ID_IMAGE>
# con el ID de la imagen

docker run <TAG_IMAGE>
# con el tag definido de la imagen. Si no se especifica una versión, cargará la última.

docker run <TAG_IMAGE>:<VERSION_IMAGE>
# con el tag y la versin específica de la imagen.
```

A este comando se le pueden incluir diversas opciones para definir más parámetros requeridos para el contenedor.

### `-n` | `--name`

Con esta opción podemos definir un _nombre_ al contenedor, para que el sistema no genere uno aleatorio.

```shell
docker run --name node_test node:test
```

### `-p`

Si la aplicación es un servicio web, podemos definir con esta opción el _puerto_ por el que va a salir y el puerto que se ha configurado en la _imagen_ que va a escuchar.

```shell
docker run --name node_test -p 3000:3000 node:test
```

### `-a` | `-d`

Un _contenedor_ se puede arrancar en **segundo plano** o se puede arrancar en **primer plano**:

```shell
docker run --name node_test -p 3000:3000 -d node:test
# El contenedor arranca en segundo plano y nos deja disponible la consola de comandos

docker run --name node_test -p 3000:3000 -a node:test
# El contenedor arranca en primer plano y mantiene ocupada la consola de comandos

docker run --name node_test -p 3000:3000 node:test
# Si no se especifica nada, es igual que arrancarla en primer plano
```

Si ejecutamos el _contenedor_ en segundo plano, pero la queremos recuperar para tenerla en primer plano, podemos ejecutar el siguiente comando:

```shell
docker attach <CONTAINER_ID>
```

### `-it`

Comando con el que podemos tener una **consola interactiva** del _contenedor_ que se ha arrancado.

```shell
docker run -it --name node_test -p 3000:3000 node:test
```

### `--rm`

Comando para **eliminar automáticamente** el _contenedor_ cuando se detenga.

```shell
docker run -it --name node_test -p 3000:3000 --rm node:test
```

### Comandos para contenedores ya creados: [[Start_Stop Containers]]










#docker #commandline #containers