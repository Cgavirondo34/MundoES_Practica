Cuando se cae un *nodo* donde se encuentran unos *pods* que no tienen replicas en otros nodos, *Kubernetes* tiene dos comportamientos:

* Si el *nodo* se levanta inmediatamente, el *kubelet* levanta los pods para que la perdida de conectividad sea mínima.

* Si pasan **5 minutos** desde la caida del *pod*, *Kubernetes* considera al *nodo* muerto. Si existían *pods* dentro del *nodo* que se encontraran identificados dentro del *ReplicaSet*, lo que sucede es que ese *pod* se replicará en otro de los *nodos* activos. Este lapso de tiempo que *Kubernetes* deja de margen, se conoce como **pod-eviction-timeout**, que se puede configurar en el **controller-manager**. Si finalmente se levanta el *nodo*, éste se levanta vacío y sin los *pods* que tenía configurados.

Si se sabe con certeza que el *nodo* puede volver a estar en marcha antes de los 5 minutos, se puede hacer un pequeño upgrade y reinicio del *nodo*.

Como generalmente no podemos saber el tiempo que estará caido el *nodo*, **existe un modo de pasarle la carga de trabajo a otro *nodo***. El modo de hacerlo es con el comando `drain`:

```shell
# Estructura
kubectl drain <node_name>

# Ejemplo
kubectl drain node-01
```

Por otro lado, el *nodo* del que se han drenado los *pods* queda **marcado como inaccesible** (Unschedulable) hasta que, manualmente, se elimine esa restricción. Para **quitar la restricción** una vez verificamos que el *nodo* vuelve a estar operatvo, usamos el comando `uncordon`:

```shell
# Estructura
kubectl uncordon <node_name>

# Ejemplo
kubectl uncordon node-01
```

Después de esto, el nodo que ya queda accesible no recuperará automáticamente los nodos que tenía configurados.

Por último, tenemos la posibilidad de marcar como **inaccesible** un *nodo* sin drenarle los *pods* que contiene. Esto lo podemos hacer con el comando `cordon`:

```shell
# Estructura
kubectl cordon <node_name>

# Ejemplo
kubectl cordon node-01
```















#kubernetes #k8s #upgrade #OS
