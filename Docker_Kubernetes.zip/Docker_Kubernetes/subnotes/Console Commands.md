[Kubectl Commands Doc](https://kubernetes.io/docs/reference/generated/kubectl/kubectl-commands)

### `kubectl create`
Comando para crear *Deployments* tan solo con la consola de comandos. Admite una serie de opciones:

```shell
# **Create a deployment**
kubectl create deployment --image=nginx nginx

# **Generate Deployment YAML file (-o yaml). Don't create it(--dry-run)**
kubectl create deployment --image=nginx nginx --dry-run=client -o yaml

#**Generate Deployment YAML file (-o yaml). Don't create it(--dry-run) with 4 Replicas (--replicas=4)**
kubectl create deployment --image=nginx nginx --dry-run=client -o yaml > nginx-deployment.yaml

# **Save it to a file, make necessary changes to the file (for example, adding more replicas) and then create the deployment.**

kubectl create -f nginx-deployment.yaml

# **OR**
# **In k8s version 1.19+, we can specify the --replicas option to create a deployment with 4 replicas.**
kubectl create deployment --image=nginx nginx --replicas=4 --dry-run=client -o yaml > nginx-deployment.yaml
```

### `kubectl create -f pod-definition.yml`
Comando para crear un *Pod* desde un fichero de configuración `YAML`. Esto es aplicable a *Deployment*, *Service* y otros componentes.

### `kubectl create -f pod-definition.yml --namespace=kube-system`
Comando que se puede utilizar para los distintos assests. Se utiliza para crear assets de **otro cluster**, especificando para ello en el parámetro **su namespace**.

### `kubectl describe pod myapp-pod`
Comando para obtener información detallada en cuanto al *Pod*. Esto es aplicable a *Deployment*, *Service* y otros componentes.

### `kubectl replace -f replicaset-definition.yml`
Comando para cargar alguna modificación realizada sobre el archivo de configuración. Esto es aplicable a *Deployment*, *Service* y otros componentes.

### `kubectl scale --replicas=6 -f replicaset-definition.yml`
### `kubectl scale --replicas=6 replicaset myapp-replicaset`
Comandos para redefinir el número de replicas que se hayan definido en el archivo de configuración de *ReplicaSet*. Estos comandos **no modifican el fichero de configuración**, cuando se realiza el reinicio del nodo, los valores vuelven a los del archivo de configuración.

### `kubectl run`
Comando para poder crear *Pods* tan solo con este comando. Admite una serie de opciones:

```shell
# **Create an NGINX Pod**
kubectl run nginx --image=nginx

# **Generate POD Manifest YAML file (-o yaml). Don't create it(--dry-run)**
kubectl run nginx --image=nginx --dry-run=client -o yaml
```

### `kubectl get pods --namespace=kube-system`
Comando que se puede utilizar para los distintos assests. Se utiliza para obtener información de **otro cluster**, especificando para ello en el parámetro **su namespace**.

### `kubectl get pods --all-namespaces`
Comando para poder visualizar *todos los assets* que pasemos por parámetros en **distintos namespaces** al que nos encontramos.

### `kubectl get all`
Comando para poder visualizar todos los assets desplegados por *Kubernetes*. 

### `kubectl get pods --selector app=myapp`
Comando que incluye la opción `selector` que permite filtrar la lista de *assets* por los `labels` definidos en los archivos de configuración.

### `kubectl edit deployment nginx`
Comando para poder modificar el archivo de configuración de *cualquier asset* que necesitemos modificar, en este caso por el *nombre del asset*. En este caso no se estaría cambiando el archivo de configuración que haya podido crearse manualmente, se estaría modificando el archivo de configuración del **sistema de kubernetes**.

### `kubectl replace`
Comando para actualizar *cualquier asset* del que se haya modificado algo de configuración. Si en vez de este comando se utilizara `kubectl create`, el sistema nos devolvería un mensaje de error especificando que el asset ya existe.

Tiene distintas opciones para poder aplicar los cambios:

```shell
# Para reemplazar la configuración de un asset levantado por una nueva configuración
kubectl replace -f nginx.yaml

# Para modificar un asset, eliminando por completo lo que hay y volviendolo a cargar
kubectl relace --force -f nginx.yaml
```

### `kubectl set image <deployment> <name=image>`
Comando para poder configurar una imagen a un *deployment* que tengamos ya configurado.

Un ejemplo:

```shell
kubectl set image deployment/myapp-deployment nginx=nginx:1.9.1
```

### `kubectl exec -it <pod-name>`
Con este comando se pueden ejecutar instrucciones en el contenedor a través de una terminal interactiva.

Por ejemplo:

```shell
kubectl exec -it myapp-pod -- cat /log/myapp.log
```

### `kubectl logs <pod_name> -c <container_name>`
Comando para poder ver los logs que se han generado del contenedor dentro del pod. 

Un ejemplo es:

```shell
kubectl logs orange -c orange-container
```

### `watch kubectl get <component>`
Con este comando podemos ver en tiempo real el estado de los componentes que queramos visualizar. Por ejemplo, si queremos ver en qué momento un *nodo* esta listo, podemos ejecutar el comando:

```shell
watch kubectl get nodes
```

### `kubectl config get-clusters`
Comando para obtener un listado de todos los *clusters* levantados.

### `kubectl config use-contest <cluster_name>`
Comando para cambiar de un *cluster* a otro y poder revisar los componentes desplegados.



#kubernetes #k8s #imperative #commandline 