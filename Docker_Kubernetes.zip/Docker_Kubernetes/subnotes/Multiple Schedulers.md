Además del *Scheduler* por defecto que levanta **Kubernetes** en el cluster, se pueden generar *schedulers personalizados* para asignarlos a *pods específicos*.

Para poder generar nuestro propio *scheduler* creamos un nuevo fichero de configuración:

**my-scheduler.yml**
```yaml
apiVersion: kubescheduler.config.k8s.io/v1
kind: KubeSchedulerConfiguration
profiles:
- schedulerName: my-scheduler
```

Después de esto, incorporamos la ruta en el archivo de configuración `kube-scheduler.service` en la opción:

```YAML
ExecStart=/user/lcoal/bin/kube-scheduler --config=/etc/kubernetes/config/kube-scheduler.yml
```

Cada archivo de configuración *scheduler* utiliza su propio archivo de configuración `kube-scheduler.service`.

También se pueden crear **schedulers como pods**, creando un *pod* con campos específicos del *scheduler* y apuntando al archivo de configuración `my-scheduler.yml`:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: my-custom-scheduler
	namespace: kube-system
spec:
	containers:
	- command:
		- kube-scheduler
		- --address=127.0.0.1
		- --kubeconfig=/etc/kubernetes/scheduler.conf
		- --config=/etc/kubernetes/my-scheduler.yml
	  image: k8s.gcr.io/kube-scheduler-amd64:v1.11.3
	  name: kube-scheduler 
```

Por último, podemos realizar otro tipo de archivo de configuración para los *scheduler* en distintos *master nodes*, fijando uno de esos *scheduler* como **Leader**:

```yaml
apiVersion: kubescheduler.config.k8s.io/v1
kind: KubeSchedulerConfiguration
profiles:
- schedulerName: my-scheduler
leaderElection:
	leaderElect: true
	resourceNamespace: kube-system
	resourceName: lock-object-my-scheduler
```

Para asignar a un *pod* el *scheduler personalizado* que hemos creado, tendremos que incorporar en la definición del *pod* el parámetro `schedulerName:`:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: nginx
spec:
	containers:
	- image: nginx
	- name: nginx
	schedulerName: my-custom-scheduler
```

Para poder saber que *scheduler* tiene asignado cada *pod*, podemos usar el siguiente comando para poder visualizar todos los eventos que han sucecido en el cluster:

```shell
kubectl get events -o wide
```

También se pueden visualizar los **logs** con el siguiente comando:

```shell
kubectl logs my-custom-scheduler --name-space=kube-system
```













#kubernetes #k8s #config #scheduler 