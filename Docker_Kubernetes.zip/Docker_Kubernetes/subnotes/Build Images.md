Para construir una imagen que hayamos definido en un _Dockerfile_ podemos usar el comando:

```shell
docker build .
# El punto(.) define el path donde se encuentra el Dockerfile, en este caso en la misma ruta donde se está ejecutando el comando.
```

A este comando le podemos añadir opciones para poder definir un `TAG` y una `Version` de la imagen, por si queremos tenerla identificada o para facilitar su uso cuando levantemos el _contenedor_.

```shell
docker build -t node_course:test .
# Definimos el TAG "node_course" con la Versión "test"
```






#docker #commandline