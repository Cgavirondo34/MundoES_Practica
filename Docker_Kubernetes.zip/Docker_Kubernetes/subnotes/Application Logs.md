Para poder visualizar los logs de un *contenendor* que se encuentra dentro de un *pod*, es parecido a **Docker** pero tenemos que especificar el nombre del *pod* y el nombre del *contenedor* contenido dentro:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: event-simulator-pod
spec:
	containers:
	- name: event-simulator
	  image: nginx
	- name: image-processor
	  image: ubuntu
```

```shell
kubectl logs -f event-simnulator-pod event-simulator

# La opción -f nos permite ver las últimas líneas del log en tiempo real
```






#kubernetes #k8s #monitoring #logs #containers 