Es una configuración que se ocupa de levantar un *Pod* en cada *nodo* que exista o que se cree nuevo en el cluster.

Generalmente, uno de los usos que se le da es el de desplegar un *Pod* para el **kube-proxy**. También es bastante útil para el despliegue de *Pods* que puedan actuar como **soluciones de monitorización o log viewers**.

```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata:
	name: monitoring-daemon
spec:
	selector:
		matchLabels:
			app: monitoring-agent
	template:
		metadata:
			labels:
				app: monitoring-agent
		spec:
			containers:
			- name: monitoring-agent
			  image: monitoring-agent
```








#kubernetes #k8s #daemon #config #pod 