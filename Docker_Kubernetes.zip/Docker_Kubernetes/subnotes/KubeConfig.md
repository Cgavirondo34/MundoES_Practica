#### KubeConfig
Cada vez uue lanzamos un request  al *kube-apiserver* tendríamos que estar identificandonos con nuestros certificados para poder validar nuestros permisos como usuario, pero esto se puede automatizar y agilizar generando un archivo de configuración que contenga toda la información sobre nuestra identificación.

Para ello, usaremos la configuración del componente **KubeConfig** que generalmente se encuentra dentro de la ruta `$HOME/.kube/config`. Teniendo esta configuración, podríamos pasarlo como opción al realizar cualquier acción con `kubectl`:

```shell
kubectl get pods --kubeconfig config
```

Por suerte, el propio sistema ya se ocupa de realizar esta acción por defecto y busca nuestro archivo `config` dentro de la ruta especificada, por lo que solo queda ver como construir este fichero.

El formato del **KubeConfig** es el siguiente:

* Tiene tres secciones: 
	* _Clusters_: Donde se definen los clusters a los que se debe tener acceso, 
	* _Users_: Los usuarios que deben tener acceso y 
	* _Contexts_: Donde se relacionan a los usuarios con los cluster, especificando a qué y donde tienen permiso.

```yaml
apiVersion: v1
kind: Config
current-context: my-kube-admin@my-kube-playground
clusters:
- name: my-kube-playground
  cluster:
	  certificate-authority: <path_to_ca_crt>
	  certificate-authority-data: <crt_codificado_en_base64>
	  server: https://my-kube-playground:6443
contexts:
- name: my-kube-admin@my-kube-playground
  context:
	  cluster: my-kube-playground
	  user: my-kube-admin
	  namespace: <nombre_del_namespace>
users:
- name: my-kube-admin
  user:
	  client-certificate: <path_to_client_crt>
	  client-key: <path_to_client_key>
```

El campo `current-context` sirve para definir uno de los *context* por defecto.

En el campo `namespace` podemos especificar un namespace si el cluster tiene varios definidos.

Para los *CA* podemos *definir el path* donde se encuentra el certificado o bien directamente *la clave codificada en base64*.

Podemos visualizar qué archivo de configuración está leyendo **Kubernetes** por defecto con el comando:

```shell
kubectl config view
```

Y para poder visualizar otra configuración, tendríamos que especificarlo en el comando con la opción `--kubeconfig`:

```shell
kubectl config view --kubeconfig=my-custom-config
```

Si queremos cambiar la opción de `current-context`, podemos usar el comando:

```shell
kubectl config use-context <contexto_a_utilizar>

# Si se utiliza el archivo de configuración de Kubernetes
kubectl config use-context prod-user@production

# Si se utiliza el archivo de configuración personalizado
kubectl config --kubeconfig=/root/my-kube-config use-context dev-user@test-cluster-1
```
