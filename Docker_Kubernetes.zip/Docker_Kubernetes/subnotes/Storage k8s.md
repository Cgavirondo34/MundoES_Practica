Para entender como funciona el almacenamiento en **Kubernetes**, antes hay que entender el almacenamiento en **Docker**.

## Almacenamiento en Docker
Cuando se instala **Docker**, la ruta donde se almacenan todos los datos relacionados con su instalación, configuración, imagenes, contenedores, ... es en `/var/lib/docker`.

Si se generan *named volumes* por ejemplo, todos los datos se almacenaran en esta ruta en `volumes/[bind_volume]`.

## Almacenamiento en Kubernetes

### Volumes
Por defecto, al igual que con **Docker**, tenemos que cuando se genera un *Pod* el *volumen* y su contenido se destruyen cuando el *Pod* se cierra o se finaliza.

Podemos definir un volumen para que esos datos persistan dentro de la configuración del *Pod*:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: random-number-generator
spec:
	containers:
	- image: alpine
	  name: alpine
	  command: ["/bin/sh", "-c"]
	  args: ["shuf -i 0.100 -n 1 >> /opt/number.out"]
	  volumeMounts:
	  - mountPath: /opt
	    name: data-volume		  
	volumes:
	- name: data-volume
	  hostPath:
		  path: /data
		  type: Directory
```

Con el tag `volumeMounts:` definimos el directorio donde se van a almacenar los ficheros dentro del *contenedor* y el nombre del *volumen* que se va a generar e identificar en el siguiente tag.

Con el tag `volumes:` definimos un volumen y le damos la ruta dentro de la decfinición de *volumen* en el *host* donde va a desplegarse, de modo que siempre que se cierre y se abra el *Pod* dispondremos de los datos contenidos.

No se recomienda usar el mismo *volumen* para diferentes *nodos* porque cada uno puede acabar conteniendo diferente contenido y **Kubernetes** espera contener siempre lo mismo.

Por último, se pueden definir volumenes de servicios externos.

### Persistent Volumes
Se pueden definir los volúmenes de modo más centralizado con la definición de *volúmenes persistentes*. De este modo se pueden definir valores como el tamaño máximo para que solo se tenga que realizar la llamada desde el *Pod*, pudiendo limitar el uso de este volumen por cada *Pod*.

Para la definición de un *volumen persistente* generamos un archivo de configuración con la siguiente estructura:

```yaml
apiVersion: v1
kind: PersistentVolume
metadata:
	name: pv-vol1
spec:
	accessModes:
	- ReadWriteOnce    ## ReadWriteOne | ReadOnlyMany | ReadWriteMany
	capacity:
		storage: 1Gi
	hostPath:
		path: /tmp/data
```

Se puede definir un tag extra llamado `persistentVolumeReclaimPolicy:` que por defecto tiene definida la opción `Retain`. Esto es que si se elimina un *PVC* asociado, este *PV* no se eliminará salvo que se elimine manualmente; otrra opción es `Delete` que hará lo contrario; por último, tenemos la opción `Recycle` que lo que hará es mantener el *PV* pero eliminará lo contenido por el *PVC*.

### Persistent Volume Claims
Es la configuración que se realiza para reclamar una porción del *Persistent Volume* definido anteriormente. Cada *PVC* va siempre asociado a un *PV*.

La definición es del siguiente modo:

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
	name: myclaim
spec:
	accessModes:
	- ReadWriteOnce
	resources:
		requests:
			storage: 500Mi
```

Si no se define una asociación a un *Persistent Volume* específico al través del tag `selector:`, **Kubernetes** vinculará directamente el *Persistent Volume Claim* a un *Persistent  Volume* que pueda cumplir con los requisitos del primero.

Para poder usar el *PVC* desde un *Pod*, un *Deployment* o un *ReplicaSet* tenemos que que incluirlo en la definición del *Pod* del siguiente modo:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: mypod
spec:
	containers:
	- name: myfrontend
	  image: nginx
	  volumeMounts:
		- mountPath: "/var/www/html"
		  name: mypd
	volumes:
	- name: mypd
	  persistentVolumeClaim:
		claimName: myclaim
```

## Storage Class
En algunas ocasiones, sobre todo en entornos cloud, antes de generar un *PV* es necesario crear el almacenamiento para poder reclamarlo posteriormente. Esto se conoce como **Static Provisioning**.

Existe la posibilidad de generar un componente llamado *Storage Class* que lo que hace es que, cada vez que la aplicación reclame aprovisionamiento de volumen, automáticamente el volumen genera el almacenamiento solicitado por la aplicación. Con este nuevo componente se puede automatizar la gestión de volúmenes en el cloud. A esto se le llama *Dynamic Provisioning*.

Para poder definir este nuevo componente, generamos el siguiente documento:

```yaml
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
	name: google-storage
provisioner: kubernetes.io/gce-pd
```

Teniendo la definición de este nuevo componente **no sería necesario generar el componente PV**. Tenemos que incorporar un nuevo campo en la definición del *PVC* `storageClassName: ` incluyendo el nombre del *Storage Class* creado.

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
	name: myclaim
spec:
	accessModes:
	- ReadWriteOnce
	storageClassName: google-storage
	resources:
		requests:
			storage: 500Mi
```










#kubernetes #k8s #storage #volumes 