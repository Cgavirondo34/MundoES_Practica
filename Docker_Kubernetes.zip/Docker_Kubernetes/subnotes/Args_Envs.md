## Argumentos
Los argumentos nos permiten declarar variables que solo se encontraran disponibles dentro del **Dockerfile** pero no podrán usarse para los comandos de _contenedor_, como `CMD`. Tampoco se encontraran disponibles dentro del entorno de la aplicación.

Se pueden incluir a través de comando durante la _construcción de la imagen_:

```shell
docker build -t node:test --build-arg NICKNAME=WARCKOR .
```

O dentro de nuestro **Dockerfile**:

```shell
ARG NICKNAME=WARCKOR
```


## Variables de entorno
Las variables de entorno las podemos definir y éstas persistiran dentro del contenedor de nuestra aplicación.

Se pueden definir a través de comando durante el _arranque del contenedor_:

```shell
docker run --name node_test -p 3000:3000 --env NICKNAME=WARCKOR --rm node:test
```

O dentro de nuestro **Dockerfile**:

```shell
# Definimos la variable y su valor
ENV NICKNAME WARCKOR

# Dentro del propio Dockerfile, se puede invocar con el $
VOLUME ["/app/$NICKNAME"]
```

También podemos crear, dentro de la ruta que queramos, un fichero llamado _.env_ donde podemos definir todas las _variables de entorno_ que necesitemos.

Después tendremos que definir donde se encuentra ubicado cuando arranquemos el _contenedor_ incluyendo la opción `--env-file` en la consola de comandos, del siguiente modo:

```shell
docker run --name node_test -p 3000:3000 --env-file "path/env/file/.env" --rm node:test
```








#docker #dockerfile