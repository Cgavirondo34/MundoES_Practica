## Comunicación con el exterior
Se puede configurar el contenedor para que, en caso que la aplicación requiera realizar llamadas fuera de nuestra red local o recibirlas desde el exterior, pueda hacerlo.

Los contenedores pueden enviar llamadas al exterior sin realizar ningún tipo de configuración.

## Comunicación con localhost
Si nuestra aplicación tiene algún tipo de configuración en la que realiza una petición a algún servicio de nuestro localhost, y tenemos definido el servicio `http://localhost:----`, podemos sustituir _localhost_ por _host.docker.internal_.

De este modo, _Docker_ podrá identificar ese parámetro y permitir la conexión a nuestro _localhost_.

## Comunicación con otro contenedor
Si tuvieramos un _contenedor_ con nuestra **aplicación** y otro _contenedor_ con nuestra **base de datos**, podemos definir una **red única** para todos los contenedores que decidamos que se encuentren dentro. 

Para ello, lo primero que tendremos que hacer es crear esta red con el comando:

```shell
docker network create <NOMBRE_RED>
```

Con el siguiente comando, podremos listar todas las redes generadas:

```shell
docker network ls
```

Posteriormente, cuando arranquemos los contenedores que queremos que se comuniquen, tendremos que incorporar la opción `--network <NETWORK_NAME>` dentro del arranque:

```shell
docker run --name node_test -p 3000:3000 -d --rm --network <NETWORK_NAME> node:test
```

Por último, en la configuración de la conexión a la **base de datos** de nuestra **aplicación**, en vez de definir la IP o _localhost_, simplemente pondremos el nombre del _contenedor_ de la **base de datos**.






#docker #networks #containers  