# DNS

Para poder configurar los *DNS* en **sistemas linux**, podemos definir en la máquina que realiza la llamada un host nuevo con la IP de la otra máquina y el nombre con el que queremos definirlo en `/etc/hosts`:

```shell
# /etc/hosts

192.168.1.115   test
```

De este modo podremos llamar a la otra máquina directamente con su *DNS*. 

En el caso de tener que definir varios *DNS*, podemos crear una nueva máquina que se encargue de tener identificadas todas estas máquinas (DNS_Server), y desde nuestra máquina principal especificar donde tiene que ir a realizar la identificación de servidores. Esto lo configuramos en nuestra máquina principal en el fichero de configuración `/etc/resolv.conf`:

```shell
# /etc/resolv.conf

nameserver     192.168.1.100
```

Si tenemos identificada una máquina en nuestro servidor principal e identificada también en nuestro *DNS_Server*, podemos especificar la prioridad a la hora de realizar la identificación en el archivo de configuración `/etc/nsswitch.conf` donde **files** será el servidor principal y **dns** nuestro *DNS_Server*.

```shell
# /etc/nvsswitch.conf

hosts:     files dns
```

Para poder encontrar los datos de un servicio web a través de su *DNS* o a través de su *IP* se puede utilizar el comando `nslookup` con el que obtendremos toda su información.

Existe otro comando que facilita aun más información, es con `dig`.

# Kubernetes Networking Model

En **Kubernetes** el modelo de comunicación que existe debe cumplir estas condiciones de manera estandarizada:

* Cada *Pod* debe tener una IP.
* Cada *Pod* debe poder comunicarse con todos los *Pod* del mismo nodo.
* Cada *Pod* debe poder comunicarse con todos los *Pod* del resto de nodos sin NAT.

Para poder implementar este modelo existen herramientas externas como son:
* *flannel*
* *cilium*
* *VMWare NSX*

También podemos implementarlo manualmente en *linux* del siguiente modo:

1. Creamos un **virtual bridge** en cada nodo y los levantamos con los comandos:

```shell
# Nodo 1
# ... Creamos el virtual bridge
ip link add v-net-0 type bridge
# ... Levantamos el virtual bridge
ip link set deve v-net-0 up

# Nodo 2
# ... Creamos el virtual bridge
ip link add v-net-0 type bridge
# ... Levantamos el virtual bridge
ip link set deve v-net-0 up
```

2. Como cada nodo se va a encontrar en su propia subred, definimos esa subred por cada nodo:

```shell
# Nodo 1
ip addr add 10.244.1.0/24 dev v-net-0

# Nodo 2
ip addr add 10.244.2.0/24 dev v-net-0
```

3. Para incluir un contenedor a la red, tendremos el siguiente comando para cada contenedor, que genera un nuevo **cable** para realizar la conexión entre el contenedor y el **virtual bridge**:

```shell
ip link add veth-red type veth peer name veth-red-br
```

4. Ahora conectamos una salida de la red al contenedor y el otro extremo al **virtual bridge**:

```shell
# Salida que conecta al pod
ip link set veth-red netns red

# Salida que conecta al virtual bridge
ip link set veth-red-br master v-net-0
```

5. Asignamos una IP al contenedor e introducimos una ruta hacia el gateway:

```shell
ip -n red addr add 192.168.15.1 dev veth-red
```

6. Levantamos la interfaz del contenedor:

```shell
# Levantamos interfaz del cable
ip -n red link set veth-red up
```

7. Configuramos la conexión entre *Pods*, añadiendo la ruta entre el *Pod* y el *Nodo*:

```shell
# Pod del nodo 1 en nodo 1
ip router add 10.244.1.2 via 192.168.1.11

# Pod del nodo 2 en nodo 2
ip router add 10.244.2.2 via 192.168.1.12

# Pod del nodo 1 con nodo 2
ip router add 10.244.1.2 via 192.168.1.12

# Pod del nodo 2 con nodo 1
ip router add 10.244.2.2 via 192.168.1.11
```

Todos estos pasos pueden servir si la red es pequeña, pero si la red es grande podemos utilizar el **Container Network Interface (CNI)** de **Kubernetes**, que nos permite generar un script de automatización para *la creación y la eliminación*. Lo vemos en la siguiente sección.

## Container Network Interface (CNI)

El **CNI** es un plugin de **Kubernetes** que se configura en el archivo de configuración del *Kubelet*:

```yaml
# kubelet.service
ExecStart=/usr/local/bin/kubelet \\
	-- config=/var/lib/kubelet/kubelet-config.yaml \\
	.....
	--network-plugin=cni \\            <-------
	--cni-bin-dir=/opt/cni/bin \\      <-------
	--cni-conf-dir=/etc/cni/net.d \\   <-------
	--register-node=true \\
	--v=2	
```

Esta configuración se podría visualizar también utilizando el comando:

```shell
ps -aux | grep kubelet
```

La ruta `/opt/cni/bin` contiene varios de los ejecutables del plugin **CNI**.

La ruta `/etc/cni/net.d` contiene archivos de configuración para los ejecutables de la ruta anterior.

### CNI WeaveWorks

Se trata de una solución **CNI** de terceros.

La instalación a día de hoy sería con el comando:

```shell
kubectl apply -f https://github.com/weaveworks/weave/releases/download/v2.8.1/weave-daemonset-k8s.yaml
```

Esta solución se ocupa de instalar un *agente en cada nodo* para poder administrar las comunicaciones. Para poder desplegar el agente en cada nodo, lo que se hace es desplegarlos como *services* o *daemons* si se configura manualmente. 

Si **Kubernetes** ya está instalado y configurado, entonces la mejor opción es instalarlos como *Pods* en el clúster. Esto podemos hacerlo con el siguiente comando:

```shell
kubectl apply -f "https://github.com/weaveworks/weave/releases/download/v2.8.1/weave-daemonset-k8s.yaml"
```

De este modo, durante la instalación en el clúster como un *daemonset*, de modo que esto forzará a la instalación de al menos un agente como *Pod* en cada nodo. Podemos encontrar los agentes luego como *Pods* con el comando para listarlos.

Por último, para poder ver sus logs podemos usar el comando:

```shell
kubectl logs <nombre_pod> weave -n kube-system
```









#kubernetes #k8s #networks #CNI #DNS 