**Documentation**: [Kubernetes API](https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.26/#-strong-api-overview-strong-)

Podemos crear archivos `.conf` para definir el despliegue y servicio de nuestra aplicación como hacemos con *Docker-Compose*. El nombre del fichero puede ser cualquiera.

## Archivos de configuración

### Estructura Deployment.conf: [[Deployment Config K8s File]]

### Estructura Service.conf: [[Service Config K8s File]]

### Estructura Pod.conf: [[Pod Config K8s File]]

### Estructura ReplicaSet.conf: [[ReplicaSet Config K8s File]]

### Estructura Namespace: [[Namespace Config K8s File]]

## Selectores

Los selectores o `selector` se utiliza para conectar recursos. En el selector se especifican etiquetas que luego se conectaran con aquellos servicios o despliegues que tengan estas etiquetas en el `matchLabels`.




#kubernetes #k8s #declarative #services 
