Esta configuración, de un modo similar a los **Node Selectors**, nos permite definir criterios de despliegue en los *Pods* filtrando por los *nodos* que se ajusten y definan.

Un ejemplo de configuración es:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: myapp-prod
spec:
	containers:
	- name: data-processor
	  image: data-processor
	affinity:
		nodeAffinity:
			requiredDuringSchedulingIgnoreDuringExecution:
				nodeSelectorTerms:
				- matchExpressions:
				  - key: size
					operator: In
					values:
					- Large
					- Medium
```

Si no existen *nodos*, pero ninguno de ellos tiene definido el tag correspondiente, justo después de la definición de `nodeAffinity` tenemos una etiqueta que especifica el comportamiento:

- *requiredDuringSchedulingIgnoredDuringExecution*: 
	- **DuringScheduling**: si en el momento de crear un nuevo *Pod*, no existe un *nodo* con una definición que se ajuste, el *Pod* no se desplegará.
	
	- **DuringExecution**: Si se cambia la configuración del *nodo*, los *Pods* ya desplegados no se verán afectados, a menos que se vuelvan a desplegar.

- *preferredDuringSchedulingIgnoredDuringExecution*:
	- **DuringScheduling**: si en el momento de crear un nuevo *Pod*, no existe un *nodo* con una definición que se ajuste, el *Pod* se desplegará igualmente en otro. **Preferiblemente**, se desplegará en el *nodo* que si contenga la definición.
	
	- **DuringExecution**: Si se cambia la configuración del *nodo*, los *Pods* ya desplegados no se verán afectados, a menos que se vuelvan a desplegar.

- *requiredDuringSchedulingRequiredDuringExecution*:
	- **DuringScheduling**: si en el momento de crear un nuevo *Pod*, no existe un *nodo* con una definición que se ajuste, el *Pod* no se desplegará.
	
	- **DuringExecution**: Si se cambia la configuración del *nodo*, los *Pods* ya desplegados se verán afectados por el cambio y, si no tienen la definición del *nodo*, dejaran de estar desplegados en el mismo.








#kubernetes #k8s #node #affinity #config #pod 