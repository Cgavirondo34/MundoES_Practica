Para levantar todos los servicios definidos en el archivo de **Docker Compose**, ejecutamos el siguiente comando:

```sh
docker-compose up
```

Este comando levanta los servicios, pero luego cierra y elimina automáticamente los contenedores. Para mantenerlo levantado y volver a tener el control de la consola, ejecutamos el comando con la opción `-d`. De este modo, se levantan los servicios y se quedan levantados en segundo plano.

```sh
docker-compose up -d
```

Para forzar que las imagenes se reconstruyan cuando volvemos a levantar los servicios en **Docker Compose**, podemos añadir la opción `--build`:

```sh
docker-compose up --build
```

Para poder finalizar la ejecución de los servicios y eliminar los contenedores, volumenes y redes generadas, usamos el siguiente comando:

```sh
docker-compose down
```

