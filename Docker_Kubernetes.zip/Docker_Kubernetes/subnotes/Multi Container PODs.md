Los multicontenedores dentro de un mismo *pod* se utiliza en los microservicios, cuando quieres dividir los servicios de la aplicación de modo que puedas escalar de manera independiente cada servicio.

Al encontrarse dentro del mismo *pod*, **comparten red y almacenamiento** así como el **ciclo de vida**.

Para generar un *pod multi-contenedor*, se definen los distintos contenedores dentro del mismo fichero de configuración:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: simple-webapp
	labels:
		name: simple-webapp
spec:
	containers:
	- name: simple-webapp
	  image: simple-webapp
	  ports:
	  - containerPort: 8080
	- name: log-agent
	  image: log-agent
```


## Modelos de diseño
Existen tres modelos comunes de diseño a la hora de diseñar la estructura de un *pod multi-contenedor*:

* **Side car pattern**
* **Adapter**
* **Ambassador**

## InitContainer
Son aquellos contenedores que se levantan para llevar a cabo algún tipo de proceso, como pasar información al contenedor donde tenemos levantada una web, y una vez ha finalizado su función se elimina el contenedor.

Para definirlo, lo hacemos dentro de la definición del *pod* como si fuera un contenedor, pero con el tag de `initContainers:`.

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: myapp-pod
	labels:
		app: myapp
spec:
	containers:
	- name: myapp-container
	  image: busybox:1.28
	  command: ['sh', '-c', 'echo The app is running! && sleep 3600']
	initContainers:
	- name: init-myservice
	  image: busybox
	  command: ['sh', '-c', 'git clone <some-repository-that-will-be-used-by-application> ; done;']
```

Cuando se inicia el *pod* con esta configuración, primero se levanta y ejecuta `initContainers:` y, una vez finalizado, se levantan el resto de contenedores normales.

Se pueden levantar multiples `initContainers:` para que vayan levantandose y ejecutandose **secuencialmente**. Si uno de estos contenedores fallara en su ejecución, el *pod* se reiniciaría cada vez hasta conseguir que se ejecuten todos.



#kubernetes #k8s #pod #multicontainer 