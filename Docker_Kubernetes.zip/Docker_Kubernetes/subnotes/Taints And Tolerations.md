 De este modo se define las restricciones que se configuran para que pueda desplegarse un *Pod* en un *Nodo* en particular. El *nodo* se restringe para que solo unos *Pods* que cumplan ciertas condiciones puedan desplegarse.

La definición de *Taint* en el *Nodo*, son las restricciones para desplegar los nodos. La definición de *Toleration* en el *Pod*, es la **autorización** o **consentimiento** para desplegar en el *Nodo* restringido.

Para definir las restricciones o *taints* en un nodo, utililzamos el comando:

```shell
kubectl taint nodes node-name key=value:taint-effect
```

* **taint-effect**: define el comportamiento del *Pod* que se incluya si no tiene tolerancia definida para ese *Nodo*. Pueden ser tres efectos:
	* *NoSchedule*: No se desplegará ningún *Pod* en este *nodo*.
	* *PreferNoSchedule*: El sistema intentará no meter un *Pod* en este *nodo*.
	* *NoExecute*: Los nuevos *Pods* no se desplegarán en el *nodo* y, los que ya existían, no operarán si no tienen tolerancia definida para ese *nodo*.

```shell
kubectl taint nodes node1 app=blue:NoSchedule
```

Para definir los permisos o *tolerations* de un *Pod*, lo podemos hacer en su fichero de configuración:

```yaml
apiVersion: v1
kind: Pod
metadata: 
	name: myapp-prod
spec:
	containers:
		- name: nginx-container
		  image: nginx
	tolerations:
		- key: "app"
		  operator: "Equal"
		  value: "blue"
		  effect: "NoSchedule"
```






#kubernetes #k8s #taint #toleration #node #pod