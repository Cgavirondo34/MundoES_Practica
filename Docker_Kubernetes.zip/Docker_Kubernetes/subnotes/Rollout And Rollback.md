Cuando generamos nuevas versiones de un *asset* se queda almacenado tanto la versión actual como la anterior. Para poder revisar el estado del despliegue de la **nueva versión**, podemos utilizar el siguiente comando:

```shell
kubectl rollout status deployment/myapp-deployment
```

Para poder ver el historial de actualizaciones, podemos usar el siguiente comando:

```shell
kubectl rollout history deployment/myapp-deployment
```

## Estrategias de despliegue

Tenemos dos estrategias que se pueden utilizar a la hora de realizar un despliegue. Para verlo, imaginemos que tenemos 5 instancias de una aplicación web:

1. *Recreate*: La primera posibilidad es destruir las cinco instancias de nuestra aplicación, para luego levantar las nuevas instancias. **Esto puede provocar que la aplicación quede sin una sola instancia funcional**.

2. *RollingUpdate*: La segunda posibilidad es destruir una instancia, levantar su actualización, destruir otra instancia, levantar su actualización, ... y así hasta haberlo hecho con todas las instancias de la aplicación. 

## Rollback
Si algo ha salido mal, se puede volver a una versión anterior de los *pods* desplegados con el comando:

```shell
kubectl rollout undo deployment/myapp-deployment
```

Esto destruye todos los *pods* generados y vuelve a levantar inmediatamente la versión anterior.

Tenemos la opción de ver el status y el historial de rollouts de los que se dispone con los comandos:

```shell
# Status de los rollout disponibles en el nodo
kubectl rollout status deployment/myapp-deployment

# Historial de los rollout
kubectl rollout history deployment/myapp-deployment
```













#kubernetes #k8s #rollout #rollback #update