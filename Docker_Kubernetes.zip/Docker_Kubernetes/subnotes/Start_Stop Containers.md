Podemos tener contenendores no arrancados, que queremos levantar nosotros manualmente. También podemos tener contenedores arrancados que queremos detener por el motivo que sea.

Para ello, tenemos la posibilidad de realizar estas operaciones desde la **consola de comandos**.

## Start container
De esta forma podemos rearrancar un _contenedor_ que ya exista:

```shell
docker start <CONTAINER_ID>
# Por ID del contenedor

docker start <CONTAINER_NAME>
# Por el nombre del contenedor
```

Este comando admite una serie de opciones.

### `-a`

Para arrancar el _contenedor_ en primer plano.

```shell
docker start -a <CONTAINER_NAME>
```

### `-i`

Para arrancar el _contenedor_ en el modo interactivo.

```shell
docker start -a <CONTAINER_NAME>
```

## Stop container
De esta forma podemos detener un _contenedor_ que se encuentra arrancado:

```shell
docker stop <CONTAINER_ID>
# Por ID del contenedor

docker stop <CONTAINER_NAME>
# Por el nombre del contenedor
```





#docker #containers 