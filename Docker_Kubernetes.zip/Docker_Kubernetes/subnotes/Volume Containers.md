Dentro de un contenedor se pueden generar volumenes de tres tipos: _anonymous volumes_, _named volumes_ y _bind volumes_.

Se pueden visualizar los volumenes existentes con el comando:

```shell
docker volume ls
```

## Anonymous Volumes
Son aquellos volumenes que _se eliminaran automáticamente_ cuando el _contenedor_ se detenga. Son volumenes pensados principalmente para almacenamiento de ficheros temporales.

El modo de declarar este tipo de volumenes en **Dockerfile**:
```shell
VOLUME ["/path/volumen/temporal"]
```

También puede declararse desde la consola cuando se arranca un contenedor:
```shell
docker run --name node_test -p 3000:3000 -v "/path/volumen/temporal" --rm node:test
```

Si el _contenedor_ no se arranca con la opción `--rm`, el _volumen_ no se eliminará una vez se detenga y elimine el _contenedor_, tendremos que eliminarlo manualmente:

```shell
docker volume rm <VOLUME_ID>
# Elimina solo el volumen seleccionado

docker volume prune
# Elimina todos los volumenes que no esten siendo usados por un contenedor
```

## Named Volumes
Son aquellos volumenes persistentes, que no comparten path en local, que se mantendran vivos aunque el _contenedor_ no se encuentre activo o se elimine.

Son volumenes de **solo lectura**, no permiten la edición de su contenido ni pueden accederse desde fuera del contenedor donde han sido invocados. Son favorables en el caso de _logs_ o ficheros que de _configuración_ que no requieren de edición.

No pueden declararse dentro de **Dockerfile**, solo pueden declararse al arrancar el contenedor con el siguiente comando:

```shell
docker run --name node_test -p 3000:3000 -v <VOLUME_NAME>:"/path/volumen/temporal" node:test
```

## Bind Volumes
Son aquellos volumenes persistentes que se encuentran **sincronizados** con una ruta local. De este modo, toda modificación que se realice en local sobre esa ruta se verá reflejado en el _contenedor_ y viceversa.

Al igual que con los **named_volumes**, no puede declararse desde el **Dockerfile**, solo puede declararse al arrancar el contenedor:

```shell
docker run --name node_test -p 3000:3000 -v "<ABSOLUTE_PATH>":"/path/volumen/temporal" node:test
```












#docker #dockerfile #volumes #containers 

