```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: second-app-deployment
spec:
  replicas: 1
  selector:
    matchLabels:
      app: second-app-deployment
      tier: backend
  template:
    metadata:
      labels:
        app: second-app-deployment
        tier: backend
    spec:
      containers:
      - name: second-app-deployment
        image: warckor/k8s_project:second
```

Para poder crear el *deployment* con el archivo `.yaml` utilizamos el siguiente comando:

```shell
kubectl apply -f=deployment.yaml
```

Para poder eliminar el *deployment* creado, podemos usar el siguiente comando:

```shell
# usando como fuente el archivo de configuracion
kubectl delete -f=deployment.yaml

# usando como fuente el nombre del deployment
kubectl delete deployment second-app-deployment
```

## Template

Los datos que se incluyen dentro de *Template* son los datos de configuración del *Pod*, donde se incluye el `metadata` para darle un nombre o unos `labels` para poder darles una identificación y poder referenciarlos en otros métodos como el de *service*. Los `spec` son la configuración del contenedor dentro del *Pod*.

## Namespace

Se puede definir el cluster donde queremos definir nuestro *Deploymet* incluyendo el parámetro `namespace:` dentro del `metadata:`. Quedaría del siguiente modo:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: second-app-deployment
  namespace: develop
spec:
  replicas: 1
  selector:
    matchLabels:
      app: second-app-deployment
      tier: backend
  template:
    metadata:
      labels:
        app: second-app-deployment
        tier: backend
    spec:
      containers:
      - name: second-app-deployment
        image: warckor/k8s_project:second
```











#kubernetes #k8s #declarative #deployment #config  