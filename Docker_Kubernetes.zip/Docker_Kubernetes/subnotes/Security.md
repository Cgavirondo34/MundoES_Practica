La seguridad básica que se debe tener en cuenta en cuanto al acceso a los *host* es: **desactivar la autenticación con contraseña** y **activar la autenticación con clave SSH**.

Para los _clusters_, hay que definir quién puede acceder y qué pueden hacer.

Para definir **quién puede acceder** se utiliza la _autenticación_. Para definir **qué pueden hacer** se utiliza la _autorización_.

Además, por defecto las comunicaciones entre *pods* que se encuentran en el mismo _cluster_ no está limitada, para ello es necesario definir lo que se conoce como **Network Policies**.

## Authentication
Por defecto, **Kubernetes** *no administra cuentas de usuario ni sus permisos*, por lo que esto se tiene que realizar externamente bien sea con archivos de configuración o herramientas de terceros.

En cambio, si puede *administrar el acceso a servicios* que requieran de acceso al *cluster*, dandolos de alta, modificandolos o eliminandolos:

```shell
kubectl create serviceaccount sa1

kubectl gert serviceaccount
```

Todo **acceso de usuario** se encuentra administrado por el *kube-apiserver*, por lo que permite distintos mecanismos para poder controlar la autenticación a través de este componente:

* *Static Password File*: Listado de usuarios y contraseñas que tienen permisos de acceso.
* *Static Token File*: Lo mismo que el anterior pero almacenando unos tokens de seguridad.
* *Certificates*: Certificado de acceso.
* *Identity Services*: Gestión de acceso de terceros con sus protocolos de seguridad.

### Basic
**Deprecado en la versión 1.19 de Kubernetes por lo que no existe esta opción en posteriores versiones.**

Tanto para *Static Password File* como para *Static Token File* se genera un archivo `.csv` donde se genera una lista de contraseñas, usuarios y UserIDs. Este fichero se define en la configuración del componente *kube-apiserver* en la opción `--basic-auth-file=user-details.csv`. Podemos definir una cuarta columna al archivo `.csv` para categorizar a los usuarios por grupo. En el caso de los tokens, la opción que hay que definir en el componente *kube-apiserver* es `--basic-auth-file=user-details.csv`.

### 1. [[TLS Certificates]]

### 2. [[KubeConfig]]


## Authorization
La **autorización** permite definir qué pueden hacer los distintos usuarios de **Kubernetes**. Son los permisos sobre las acciones posibles.

Existen distintos modos de definir las **autorizaciones**:

* *Node*: Se accede al *kube-apiserver* de los nodos del *cluster* y la autorización del **Node Authorizer** define las acciones que se pueden llevar a cabo desde el *nodo*.

* *ABAC*: Acceso externo desde el cluster. Conjunto de autorizaciones para el **usuario** o **grupo de usuarios** que accede al *kube-apiserver*. Esto se define con un *Pod* de **tipo Policy**. 

* *RBAC*: Control de Acceso Basado en Roles. Es parecido al *ABAC* pero en este caso en vez de definir los permisos para un usuario o un grupo de usuarios, definimos permisos para un **rol de usuario** (developers, admins, viewers, ...).

* *Webhook*: Este modo de autorización permite la gestión desde un mecanismo externo al sistema de **Kubernetes**, como *Open Policy Agent*, que es una herramienta de terceros.

Por otro lado, la definición de permisos puede enfocarse con dos estándares: **AllwaysAllow** y **AllwaysDeny**. Estas opciones se definen en el archivo de configuración del *kube-apiserver* con la opción `--authorization-mode=`. Si no se define esta opción, por defecto queda habilitado como **AlwaysAllow**.

#### Detalle sobre [[RBAC]]

## Service Accounts
Son las cuentas habilitadas para los servicios que tienen que interactuar con los distintos componentes de **Kubernetes** (por ejemplo, para la monitorización con Prometheus o Jenkins para la administración de pipelines).

Para crear un nuevo *Service Account* simplemente usamos el comando:

```shell
kubectl create serviceaccount dashboard-sa
```

Cuando se genera el *serviceAccount*, se **crea un token** que es el que tiene que usar la herramienta externa para poder identificarse. Este token se almacena como un *Secret*, y para poder visualizarlo tenemos que invocar su descripción del siguiente modo:

```shell
# El nombre del secret se encuentra en la descripción del ServiceAccount
kubectl describe secret dashboard-sa-token-kbbdm
```

Este token se puede utilizar por ejemplo en una llamada al API haciendo `curl` como una cabecera de tipo `Authorization: Bearer <token>`.

Si la aplicación externa, que requiere de acceso para un servicio, se encuentra dentro del *cluster* desplegado en algún *Pod* se puede montar el *Secret* como un volumen dentro del *Pod* donde se encuentra la aplicación.

Por cada *Namespace* generado en el cluster, existe un *ServiceAccount* llamada *default* con su propio token, que se configura automáticamente como un volumen en cada *Pod* que se genera dentro del *Namespace*. Si revisamos dentro de la aplicación del *Pod* la ruta `/var/run/secrets/kubernetes.io/serviceaccount` podremos encontrar el token de *default*:

```shell
kubectl exec -it my-kubernetes-dashboard ls /var/run/secrets/kubernetes.io/serviceaccount

# ca.crt    namespace    token
```

El token de *default* es bastante restrictivo, ya que solo permite realizar **consultas básicas al API de Kubernetes**. 

Si queremos usar un *ServiceAccount* propio en vez del *default*, en la definición del *Pod* tenemos que incorporar un nuevo campo `serviceAccountName`.

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: my-kubernetes-dashboard
spec:
- name: my-kubernetes-dashboard
  image: my-kubernetes-dashboard
serviceAccountName: dashboard-sa
```

Si no queremos que se asigne el token de *default* ni ningún otro, podemos especficicarlo en el archivo de configuración del *Pod* con el campo `automountServiceAccountToken` del siguiente modo:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: my-kubernetes-dashboard
spec:
- name: my-kubernetes-dashboard
  image: my-kubernetes-dashboard
autoamountServiceAccount: false
```

**A partir de la versión 1.22 se depreca la opción de insertar ServiceAccount en el Pod para dar pie al uso del ServiceAccount API Token con tecnología JWT**.

## Image Security
Se pueden descargar las imagenes y acceder a las mismas a través de distintos registros, los más populares son *Docker* y *Google*.

Un modo de securizar el acceso es a través de unas credenciales, lo cual con *Docker* puede hacerse del siguiente modo:

```shell
docker login private-registry.io
```

En el caso de la definición de imagenes en el archivo de configuración del *Pod*, lo que hacemos para poder hacer la llamada a un repositorio privado es poner `<registro.io>/<nombre_repo>/<imagen>`:

Para pasarle las credenciales al *Pod* podemos crear un nuevo componente llamado *Secret* en el que podemos generar las variables secretas para la identificación en este caso:

```shell
 kubectl create secret docker-registry regcred \
 --docker-server=private-registry.io \
 --docker-username=registry-user \
 --docker-password=registry-password \
 --docker-email=registry-user@org.com
```

Con este componente creado, podemos incorporar una referencia a *Secret* en la configuración del *Pod*

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: nginx-pod
spec:
	containers:
	- name: nginx
	  image: private-registry.io/apps/internal-app
	imagePullSecrets:
	- name: regcred
```

## Security Context
Cuando se ejecutan comandos en un contenedor de **Docker** podemos especificar el usuario o los permisos del comando ejecutado, bien sea dentro del *Dockerfile* o desde la consola:

```shell
# Con los permisos que tenga configurados el usuario
docker run --user=1001 ubuntu sleep 3600

# Con los permisos que se están especificando en el comando
docker run --cap-add MAC_ADMIN ubuntu
```

Todo esto se puede configurar directamente en **Kubernetes** a nivel de *Pod* o a nivel de *Contenedor*. Para ello, tenemos que incluir un campo llamado `securityContext:` en el archivo de configuración del *Pod*.

Si incluimos este campo fuera del contenedor, este contexto se aplicará a todos los contenedores definidos en el *Pod*:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: web-pod
spec:
	securityContext:
		runAsUser: 1000
	containers:
	- name: ubuntu
	  image: ubuntu
	  command: ["sleep", "3600"]
```

Podemos, además, definir el campo dentro de cada contenedor para que solo se aplique el contexto por contenedor. En este caso podemos incorporar un nuevo campo dentro de `securityContext` llamado `capabilities` que define los permisos de grupo que va a tener ese usuario. Esta definición solo puede hacerse dentro del contenedor:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: web-pod
spec:
	containers:
	- name: ubuntu
	  image: ubuntu
	  command: ["sleep", "3600"]
	  securityContext:
		  runAsUser: 1000
		  capabilities:
			  add: ["MAC_ADMIN"]
```

## Network Policies
Existen dos denominaciones importantes en cuanto a las redes:

* *Ingress*: Toda comunicación de entrada que se produce. Por ejemplo, del usuario al frontend, del frontend al backend o del backend a la base de datos.

* *Egress*: Toda comunicación de salida que se produce. Por ejemplo, de la base de datos al backend, del backend al frontend o del frontend al usuario.

Las respuestas que se generan en estas comunicaciones se habilitan según el sentido de la política aplicada.

En **Kubernetes** por defecto se genera una **red interna** dentro del *cluster* que permite a los distintos *nodos* y *pods* comunicarse entre ellos, con una política *All Allow* en la comunicación entre ellos.

Cuando no queremos que, por ejemplo, el *pod* del frontend se comunique directamente con el *pod* de la base de datos, implementamos las politicas de red o **network policies** y solo es aplicable al *pod* al que se lo queremos aplicar.

Para poder aplicar esta política usando como ejemplo la comunicación con la *DB_Pod* exclusivamente desde el *API_Pod*, generamos un componente *NetworkPolicy* con la siguiente estructura para la **entrada**:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
	name: db-policy
spec:
	podSelector:
		matchLabels:
			role: db
	policyTypes:
	- Ingress
	ingress:
	- from: 
	    ## Para definir el pod del que va a aplicarse la comunicación
	  - podSelector:
		  matchLabels:
			  name: api-pod
	    ## Para definirse el namespace del que se va a aplicar la comunicación
		namespaceSelector:
			matchLabels:
				name: prod
		## Para definirse servicios o componentes externos a los que permitir la comunicación
	  - ipBlock:
		  - cidr: 192.168.5.10/32
	ports:
	- protocol: TCP
	  port: 3306
```

Y ahora la misma definición si las políticas se tienen que aplicar para la **salida**:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
	name: db-policy
spec:
	podSelector:
		matchLabels:
			role: db
	policyTypes:
	- Egress
	egress:
	- to: 
	    ## Para definirse servicios o componentes externos a los que permitir la comunicación
	  - ipBlock:
		  - cidr: 192.168.5.10/32
	ports:
	- protocol: TCP
	  port: 80
```









#kubernetes #k8s #security #authentication #authorization

