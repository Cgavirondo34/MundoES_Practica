```yaml
apiVersion: v1
kind: Service
metadata:
  name: backend
spec:
  type: LoadBalancer
  selector:
    app: second-app-deployment
  ports:
    - port: 80
    - targetPort: 8080
      nodePort: 3008
  ```

Para poder crear el *service* con el archivo `.yaml` utilizamos el siguiente comando:

```shell
kubectl apply -f=service.yaml
```

Para poder eliminar el *service* creado, podemos usar el siguiente comando:

```shell
# usando como fuente el archivo de configuracion
kubectl delete -f=service.yaml

# usando como fuente el nombre del deployment
kubectl delete service backend
```

## Namespace

Se puede definir el cluster donde queremos definir nuestro *Service* incluyendo el parámetro `namespace:` dentro del `metadata:`. Quedaría del siguiente modo:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: backend
  namespace: develop
spec:
  type: LoadBalancer
  selector:
    app: second-app-deployment
  ports:
    - port: 80
    - targetPort: 8080
      nodePort: 3008
```






#kubernetes #k8s #declarative #service #config  