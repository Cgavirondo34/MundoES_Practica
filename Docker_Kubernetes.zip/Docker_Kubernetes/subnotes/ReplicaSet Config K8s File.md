## ReplicationController

Esta definición viene de versiones más antiguas de **Kubernetes**.

```yaml
apiVersion: v1
kind: ReplicationCotroller
metadata:
	name: myapp-rc
	labels:
		app: my-app
		tier: front-end
spec:
	template:
		metadata:
			name: myapp-pod
			labels:
				app-my-app
				tier: front-end
		spec:
			containers:
				- name: nginx-container
				  image: nignx
replicas: 3
```

```shell
kubectl create -f rc-definition.yml
```

```shell
kubectl get replicationcontroller
```

## ReplicaSet

Definición más actual de versiones más recientes de **Kubernetes**. La diferencia aquí es que se incluye una configuración de `selector` que nos permite controlar *Pods* que no han sido creados en la configuración inicial. Es decir, puede ocuparse de *Pods* que hayamos creado en otro momento y le queramos implementar la política de replicas definidas en esta configuración.

Aunque esta configuración este pensada para hacer replicas de *Pods* existentes, se define **un template de nuevo Pod** para generarlo en caso de no poder levantar replicas del *Pod* identificado en el campo `matchLabels`.

```yaml
apiVersion: apps/v1
kind: ReplicaSet
metadata:
	name: myapp-replicaset
	labels:
		app: my-app
		tier: front-end
spec:
	template:
		metadata:
			name: myapp-pod
			labels:
				app-my-app
				tier: front-end
		spec:
			containers:
				- name: nginx-container
				  image: nignx
replicas: 3
selector:
	matchLabels:
		tier: front-end
```

## Namespace

Se puede definir el cluster donde queremos definir nuestro *ReplicaSet* incluyendo el parámetro `namespace:` dentro del `metadata:`. Quedaría del siguiente modo:

```yaml
apiVersion: apps/v1
kind: ReplicaSet
metadata:
	name: myapp-replicaset
	labels:
		app: my-app
		tier: front-end
	namespace: develop
spec:
	template:
		metadata:
			name: myapp-pod
			labels:
				app-my-app
				tier: front-end
		spec:
			containers:
				- name: nginx-container
				  image: nignx
replicas: 3
selector:
	matchLabels:
		tier: front-end
```




#kubernetes #k8s #declarative #replicaset #config  