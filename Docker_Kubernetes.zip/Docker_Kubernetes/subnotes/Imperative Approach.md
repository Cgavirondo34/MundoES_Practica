Para poder comenzar a trabajar y orquestar nodos y despliegues en **kubernetes** tenemos que seguir los siguientes pasos:

1. Crear una nueva imagen, bien sea con `pull` o creando una imagen especifica con un *Dockerfile*.

2. Si generamos nuestra imagen con un *Dockerfile*, requerimos subir la imagen al repositorio de *Docker Hub* o al repositorio del que dispongamos como *Nexus* o *Red Hat*.

```shell
docker build -t warckor/k8s_project:first .
docker push warckor/k8s_project:first
```

Con estos primeros pasos, podemos empezar a realizar nuestro primer despliegue con `kubectl`.

## Create Deployment

Para crear nuestro primer despliegue de la imagen que hemos subido a *Docker Hub*, podemos lanzar el siguiente comando:

```shell
kubectl create deployment first-app --image=warckor/k8s_project:first
```

Esto generara nuestro primer *deployment*. Para consultar el estado podemos ejecutar:

```shell 
kubectl get deployment
```

Nos devuelve por consola un listado de *deployments* y los pods arrancados dentro. En caso de tener el resultado `0\1`, que significa que no se encuentra arrancado ningún pod, podemos consultar el motivo del error con el siguiente comando:

```shell
kubectl get pod
```

Esto nos devolvera el listado de todos los pods levantados y, en caso de error, una referencia al error que se ha producido.

## Create Service

Para crear un servicio que pueda exponer el pod que acabamos de crear, podemos ejecutar en la consola el siguiente comando:

```shell
kubectl expose deployment first-app --type=LoadBalancer --port=8080
```

En el puerto se especifica el puerto con el que trabaje la aplicación.

La opción `--type` especifica el tipo de servicio que se quiere generar. Existen principalmente tres tipos:

* *ClusterIP*: cuando el servicio solo va a facilitar comunicación entre los pods dentro del cluster.
* *NodePort*: cuando el servicio se va a exponer con IP del *worker node* que tiene levantado nuestro *deployment*.
* *LoadBalancer*: cuando el servicio genera una IP única para poder permitir el acceso a nuestro *deployment* desde el exterior. También actua como balanceador de carga cuando hay más de una réplica de nuestros pods y tiene que distribuir las llamadas entrantes.

Una vez se ha creado el servicio, podemos consultarlo con el comando:

```shell
kubectl get services
```

En el campo `EXTERNAL-IP` aparecería la IP única con la que podríamos comunicarnos con nuestra aplicación si trabajaramos, por ejemplo, con un servicio cloud. En el caso de *minikube*, siempre aparecerá como `<pending>`.

Para poder obtener la IP pública del servicio con *minikube*, tenemos que ejecutar el comando:

```shell
minikube service first-app 
```

![[Pasted image 20230211192149.png]]

## Scaling Deployments

Podemos escalar verticalmente las replicas de nuestro *pod* con el comando:

```shell
kubectl scale deployment/first-app --replicas=3
```

## Update Deployment Image

Si hemos realizado algún cambio en nuestra imagen y necesitamos actualizar la imagen que se está actualizando en nuestro *deployment*, tenemos que:

1. Volver a construir la imagen de *Docker* con `docker build -t warckor/k8s_project:second .`

2. Volver a subir al repositorio de *Docker Hub* esta nueva imagen con `docker push warckor/k8s_project:second`

3. Ejecutar el siguiente comando para actualizar la imagen que se esta ejecutando en nuestro *deployment*:

```shell
kubectl set image deployment/first-app k8s-project-kc2p2=warckor/k8s_project:second
```

El parámetro `k8s-project-kc2p2` es el contenedor que se está ejecutando en nuestro *pod*, podemos encontrarlo a través del dashboard que podemos abrir con `minikube dashboard`:

![[Pasted image 20230211200505.png]]

Por último, se puede actualizar el pod que esta ejecutandose con el comando:

```shell 
kubectl rollout status deployment/first-app
```

Si por el motivo que sea, la nueva implementación **tiene problemas** y no se levanta el nuevo *pod*, el antiguo **no se va a detener** hasta que se levante bien. Si queremos detener la actualización porque nos hemos dado cuenta que la actualización se ha introducido/creado mal, podemos ejecutar el siguiente comando para detenerlo:

```shell
kubectl rollout undo deployment/first-app
```

## Deleting Deployment/Service

Por último, para poder eliminar todo el proyecto, empezamos eliminando el *service* del siguiente modo:

```shell
kubectl delete service first-app
```

Y ahora, podemos eliminar el *deployment*:

```shell
kubectl delete deployment first-app
```





#kubernetes #k8s #imperative #deployment #services 