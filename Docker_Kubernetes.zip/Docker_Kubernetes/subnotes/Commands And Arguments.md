Tenemos la posibilidad de definir argumentos y comandos en los ficheros de configuración de los *deployment* y de los *pod*, en el espacio donde definimos los containers de modo que, si en la imagen tenemos definido un `ENTRYPOINT`, podríamos pasar el argumento desde **kubernetes**.

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: myapp
spec:
	containers:
	- name: nginx
	  image: nginx
	  args: ["10"]
```

Del mismo modo, se pueden definir comandos para ejecutar en el momento en el que se levanta el contenedor:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: myapp
spec:
	containers:
	- name: nginx
	  image: nginx
	  command: ["sleep"]
	  args: ["10"]
```















#kubernetes #k8s #commandline #arg 