Comandos básicos para la gestión de imagenes y contenedores desde la consola.

### pull

```shell
docker pull <IMAGE_NAME>
```

Con este comando podemos descargar y almacenar en local una imagen seleccionada de todas las disponibles en [Docker Hub](https://hub.docker.com/).

### images

```shell
docker images
```

Con este comando podemos listar todas las _imagenes_ que hayamos generado en local.

### ps

```shell
docker ps
```

Con este comando listamos todos los _contenedores_ que se encuentren **activos**. Podemos incluirle la opción `-a` para poder listar los _contenedores_ activos como los que están parados.

### rm

```shell
docker rm <CONTAINER_ID>
```

Con este comando eliminamos el _contenedor_ que hayamos especificado por su _ID_.

### rmi

```shell
docker rmi <IMAGE_ID>
```

Con este comando eliminamos la _imagen_ que hayamos especificado por su _ID_.

### cp

```shell
docker cp <ORIGIN_FILE> <DEST_FILE>
```

Con este comando podemos copiar un fichero desde una ruta local hasta una ruta del _contenedor_ o a la inversa.

```shell
docker cp dummy/foo.txt <CONTAINER_NAME>:/app
# Desde local hasta contenedor

docker cp <CONTAINER_NAME>:/app/foo.txt dummy
# Desde contenedor a local
```





#docker #basics