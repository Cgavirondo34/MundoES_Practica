## `docker-compose up`
