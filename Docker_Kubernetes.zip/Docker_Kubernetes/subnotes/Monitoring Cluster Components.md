Existen multitud de herramientas de monitorización, de las cuales las más relevantes son:

- Metric Server.
- Prometheus.
- Elastic Stack.
- DataDog.
- Dynatrace.

Vamos a ver parte del funcionamiento con *Metrics Server*.

## Metrics Server

El *kubelet* dispone de un componente de monitorización de recursos llamado **cAdvisor** que envía datos al servidor de métricas.

Para desplegar **metrics server** en *Minikube* simplemente ejecutamos:

```shell
minikube addons enable metrics-server
```

Si queremos instalarlo en otro tipo de instalaciones o clusters específicos, tendremos que clonar el repositorio;

```shell
# Clonamos repositorio
git clone https://github.com/kubernetes-incubator/metrics-serve

# Deploy del servicio
kubectl create -f deploy/1.8+
```

Esto instala una serie de *pods* y *servicios* que nos permitirán usar **metrics server**. Por ejemplo, podemos ejecutar el siguiente comando para ver el TOP de consumo de recursos de los nodos:

```shell
kubectl top node
```












#kubernetes #k8s #monitoring #cluster