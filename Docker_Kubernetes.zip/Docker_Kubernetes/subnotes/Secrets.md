Están pensados para almacenar datos que son más sensibles, como datos de conexión. Esta información pasa al contenedor encriptado, de modo que no queda expuesto.

## Imperativo
Existe el modo de crear este fichero de configuración de modo *imperativo*:

```shell
# Estructura
kubectl create secret generic <secret-name> --from-literal=<key>=<value>

# Ejemplo
kubectl create secret generic app-secret --from-literal=DB_Host=mysql
```

Se le puede pasar un fichero de configuración con los datos del siguiente modo:

```shell
# Estructura
kubectl create secret generic <secret-name> --from-file=<path-to-file>

# Ejemplo
kubectl create secret generic app-secret --from-file=app_secret-properties
```

El fichero del ejemplo, tendría el siguiente formato:

```yaml
DB_Host: mysql
DB_User: root
DB_Password: passwrd
```


## Declarativo
En el modo *declarativo*, tenemos que pasar los valores de las variables **encriptados**, porque si no de otro modo podría leerse. El modo para codificar los valores desde una consola Linux sería:

```shell
echo -n 'mysql' | base64
```

Ahora si, podríamos definir el archivo de configuración del siguiente modo:

```yaml
apiVersion: v1
kind: Secret
metadata:
	name: app-secret
data:
	DB_Host: bXl<xWw=
	DB_User: cm9vdA==
	DB_Password: cGFzd3Jk
```

Para poder definir la configuración de *secret* en el *pod*, tenemos dos opciones: meter en el *pod* la definición de unas variables específicas del *secret* o meter todas las variables definidas en el *secret*.

Para la primera opción, tendríamos el siguiente archivo de configuración del *pod*:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: simple-webapp-color
	labels:
		name: simple-webapp-color
spec:
	containers:
	- name: simple-webapp-color
	  image: simple-webapp-color
	  ports:
	  - containerPort:8080
	  envForm:
	  - secretKeyRef:
		  name: app-secret
		  key: dDB_Password
```

Para la segunda opción, tendremos:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: simple-webapp-color
	labels:
		name: simple-webapp-color
spec:
	containers:
	- name: simple-webapp-color
	  image: simple-webapp-color
	  ports:
	  - containerPort:8080
	  envFrom:
	  - secretRef:
		  name: app-secret
```

Por último, si tenemos que utilizar alguna de las variables de *secret* dentro de la definición de `volumes` en el *pod*, lo que haremos es:

```yaml
apiVersion: v1
kind: Pod
metadata:
	name: simple-webapp-color
	labels:
		name: simple-webapp-color
spec:
	containers:
	- name: simple-webapp-color
	  image: simple-webapp-color
	  ports:
	  - containerPort:8080
	  volumes:
	  - name: app-secret-volume
	    secret: app-secret
```








#kubernetes #k8s #env #config #secret 