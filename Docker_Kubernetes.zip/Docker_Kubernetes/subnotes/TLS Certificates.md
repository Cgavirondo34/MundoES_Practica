### TLS Certificates
Nos encontramos con tres tipos de certificados:

* _Root Certificates_: Aquellos certificados expedidos por organizaciones que abalan la autenticidad del servicio web (Symantec, Digicert, ...).
* _Server Certificates_: Certificados de acceso y comunicación de seguridad al acceder al servidor.
* _Client Certificates_: Certificados de identificación del usuario a los servidores.

En la comunicación y autenticación entre cliente y servidor, nos encontramos con dos tipos de certificados:

* _Public Key_: Es la clave pública que se comparte con el servidor donde se quiere realizar la conexión, generalmente vía SSH, que identifica al usuario. Suelen tener extensión `*.crt` y `*.pem*`.
* _Private Key_: Es la clave privada que no se comparte, es la segunda parte de la identificación entre cliente y servidor que sirve para descifrar la clave pública y validarla. Suelen tener extensión `*.key*` y `*.pem`.

En **Kubernetes** todo esto se lleva a cabo en la comunicación entre el *master node* y los *worker nodes*, entre el cliente y el nodo o entre los componentes y el *kube-apiserver*, donde se securiza a través de los *certificados TLS*.

#### Server certificates for servers
Los certificados en los servidores que nos podemos encontrar son:

* *kube-apiserver*: Tenemos un public key **apiserver.crt** y un private key **apiserver.key**.
* _etcd-server_: Tenemos un public key **etcdserver.crt** y un private key **etcdserver.key**.
* *kubelet-server*: Estos se encuentran en los *worker nodes*, y tenemos un public key **kubelet.crt** y un private key **kubelet.key**.

#### Client certificates for clients
Del lado del cliente, podemos encontrar los certificados:

* *Administradores*: Requieren de los certificados para comunicarse con el *kube-apiserver*, donde tendremos clave pública y privada.
* *Kube-scheduler*: Requiere también de los correspondientes certificados para poder realizar la comunicación con el *kube-apiserver*, con su clave pública y privada.
* *Kube-controllermanager*: Es otro cliente que realiza comunicaciones con *kube-apiserver*, por lo que también tiene su par de clave pública y privada. 
* *Kube-proxy*: Igual, realiza comunicaciones con *kube-apiserver* con su clave pública y privada.
* *Kube-apiserver*: Este componente a su vez se tiene que comunicar con el *etcd-server*, por lo que se puede considerar también un cliente. Puede utilizar las claves ya generadas como servidor o puede tener un par de claves distintas como cliente. Además, también se comunica con el *kubelet-server* en los *worker nodes*. 

#### Certificate Authorization (CA)
Para todos estos certificados, requerimos de al menos un **Certificado de Autoridad (CA)** que los valide, aunque se podría tener más de un certificado.

Estos certificados sirven para validar el resto de certificados en el entorno de **Kubernetes**, por lo que cualquiera con acceso a estos certificados puede generar nuevos usuarios y validarlos. Por ello, se requiere de algún sistema de seguridad para proteger estos certificados.

Generalmente estos certificados se almacenan en un servidor independiente o en el *master node* que permite, mediante un componente propio de **Kubernetes**, administrar la utilización de estos certificados. Este componente se llama **Certificates API** al que se pueden realizar peticiones mediante *API Rest* para validar nuevos certificados, renovarlos, ... .

#### Creación de certificados
Para la creación de todos estos certificados tenemos varias opciones como: _easyrsa_, _openssl_ o _cfssl_.

Para este caso, se va a utilizar _openssl_.

##### Certificate Authority (CA)
Para generar la *clave privada* tendríamos que ejecutar:

```shell
openssl genrsa -out ca.key 2048
```

Teniendo esto, tenemos que generar la *petición de firma*, que es un archivo con toda la información de la clave pero sin firmar, del siguiente modo:

```shell
openssl req -new -key ca.key -subj "/CN=KUBERNETES-CA" -out ca.crs
```

Finalmente, generamos la *clave firmada* con el siguiente comando:

```shell
openssl x509 -req -in ca.csr -signkey ca.key -out ca.crt
```

Todas las operaciones con certificados se encuentra administrado por el componente *Controller Manager*.

Para administrar la validación, renovación o revocación de las *claves* que lo requieran, debemos hacer lo siguiente:

1. Se genera la *clave privada* para el *certificado de clilente* del usuario.

2. Se genera una petición de validación:

```shell
openssl req -new -key jane.key -subj "/CN=jane" -out jane.csr
```

3. Este proceso genera un *Certificate Signing Request (CSR)* usando un archivo `manifest` con la configuración requerida para su validación:

```yaml
apiVersion: certificates.k8s.io/vibetal
kind: CertificateSigningRequest
metadata:
	name: jane
spec:
	groups:
	- system:authenticated
	usages:
	- digital signature
	- key encipherment
	- server auth
	request:
	<Certificado .csr en base64>
```

4. Ahora hay que codificar el `.csr` en base64 antes de meterlo en el objeto *CertificateSigningRequest*:

```shell
cat jane.csr | base64 -w 0
```

5. Con este objeto firmado en el *master node* se genera el nuevo objeto `csr`

Podemos consultar los certificados con el comando:

```
kubectl get csr
```

Esto nos da información sobre los certificados como si se encuentra pendiente de aprobación, aprobado, rechazado, caducado, ... . Si tenemos un certificado pendiente de aprobación y queremos aprobarlo, tenemos que meter el comando:

```shell
kubectl certificate approve jane
```

Una vez aprobado, este certificado ya se encuentra listo para entregarselo al usuario que requiere del certificado para poder acceder, por lo que podemos enviarle la información del `.csr` decodificado para que pueda configurar su máquina para el acceso.

##### Client Certificates
Para el usuario *adminsitrador* generamos la clave privada del siguiente modo:

```shell
openssl genrsa -out admin.key 2048
```

Ahora generamos la *clave sin firmar*:

```shell
openssl -new -key admin.key -subj "CN=kube-admin" -out admin.csr
``` 

Por último, generamos la *clave firmada*:

```shell
openssl x509 -req -in admin.csr -CA ca.crt -CAkey -out admin.crt
```

Para incorporar todos los certificados a la configuración de *kube-apiserver* podemos ejecutar un `curl` que incluirá todo esto:

```shell
curl https://kube-apiserver:6443/api/v1/pods --key admin.key --cert admin.crt --cacert ca.crt
```

También se puede incluir manualmente en el archivo de configuración `kube-config.yaml`:

```yaml
apiVersion: v1
clusters:
- cluster:
	certificate-authority: ca.crt
	server: https://kube-apiserver:6443
  name: kubernetes
kind: Config
users:
- name: kubernetes-admin
  user:
	  client-certificate: admin.crt
	  client-key: admin.key
```

Para el resto de *certificados de cliente*, vamos a seguir estos mismos pasos salvo para *kube-apiserver* y *kubelet-server*.

##### Server Certificates
###### ETCD Servers

###### Kube-Api Server

###### Kubelet Server

#### Visualizar el detalle de los certificados
Se pueden generar los certificados del modo que se menciona en los puntos anteriores, el modo "difícil", pero también existe la posibilidad de generarlos a través de la herramienta **kubeadm**.

Para poder visualizar la configuración realizada por **kubeadm**, podemos ver, en el cluster donde se encuentra instalada la herramienta, el archivo de configuración de *kube-apiserver* en la ruta: `/etc/kubernetes/manifest/kube-apiserver.yaml`.

En este fichero, tendremos todos los certificados y las rutas para los distintos servicios mencionados en el punto anterior.

Podemos visualizar los datos del certificado con el siguiente comando:

```shell
openssl x509 -in /etc/kubernetes/pki/apiserver.crt -text -noout
```

Cuando surgen incidencias con los certificados, lo mejor es empezar visualizando el log de servicios en el servidor con el comando:

```shell
journalctl -u etcd.service -l
```

En caso de haber configurado el servidor con **kubeadm**, el mejor modo de visualizar estos logs es con el comando:

```shell
kubectl logs etcd-master
```

 Si por el motivo que sea *kube-apiserver* o *etcd-server* se encuentran caídos, el comando `kubectl` no se encontrará operativo, por lo que el modo de poder visualizar los logs será a través de docker:

```shell
# Visualizamos el contenedor donde se encuentra el nodo master
docker ps -a

# Teniendo el ID del contenedor, visualizar sus logs
docker logs <ID_Container>
```











#kubernetes #k8s #security #authentication #authorization