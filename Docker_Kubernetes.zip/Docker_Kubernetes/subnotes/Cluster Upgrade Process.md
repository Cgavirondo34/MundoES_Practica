Para *Kubernetes* es principal que todos sus **componentes principales** tengan la misma versión. Estos componentes son:

* _kube-apiserver_: Como es el controlador principal, es el que define la versión. (version = X)
* _Controller-manager_: Puede estar una versión por debajo. (version = X || version = X-1)
* _kube-scheduler_: Puede estar una versión por debajo. (version = X || version = X-1)
* _kubelet_: Puede estar una o dos versiones por debajo. (version = X || version = X-1 || version = X-2)
* _kube-proxy_: Puede estar una o dos versiones por debajo. (version = X || version = X-1 || version = X-2)
* _kubectl_: Puede estar una versión por debajo o por encima. (version = X || version = X-1 || version = X+1)

Para decidir cuando se debe actualizar la versión, entre las features que ofrece la nueva versión, hay que tener en cuenta que *Kubernetes* mantiene únicamente las **dos versiones minor anteriores**. 

Una recomendación a la hora de actualizar la versión, es **hacerlo de versión en versión** y no saltar dos o más versiones a la vez.

Existen varias opciones para poder realizar las actualizaciones:
* Si se está utilizando un *managed cluster cloud*, generalmente disponen de una UI cómoda con la que poder realizar este proceso.

* Si lo hacemos a través de consola con la herramienta `kubeadm`, esta nos permite planificar las actualizaciones o actualizarlo en el momento:

```shell
# Planificado
kubeadm upgrade plan

# Inmediato
kubeadm upgrade apply
```

## Upgrade with `kubeadm`

La actualización de un *cluster* consta de dos pasos principales:

1. Actualización de los *master nodes*.
2. Después de esto, actualizar los *worker nodes*.

Mientras se actualiza el *master node*, los *worker nodes* dependientes siguen operativos. Lo que sucede es que mientras no exista comunicación con los *nodos* a través del *kube-apiserver* que se encuentra en el *master node*, no se va a poder interactuar con los *worker nodes*, ni funcionaran los *ReplicaSets* ni nada, tan solo se mantendrán vivos los *pods*.

Tras ésto, le toca actualizar a los *worker nodes*. Para ello, existen **tres estrategias** para actualizarlos:
* Actualizarlos todos a la vez, lo cual dejará fuera de servicio todos los *pods*.

* Vamos actualizando *nodos* de manera individual. Haciendo esto, los *pods* contenidos en el *nodo* que se está actualizando se levantan en los otros *nodos*.

* Incluimos un nuevo *nodo* en el *cluster*, el cual ya tiene la versión actualizada. Pasamos los *pods* de uno de los *nodos* a actualizar en este nuevo y, una vez se hayan migrado y desplegado, se elimina el *nodo* antiguo. Así con cada *nodo* individualmente.

Para poder hacer el **proceso de upgrade con `kubeadm`** tenemos el siguiente comando que nos facilita información sobre las versiones disponibles para la actualización y componentes que deben ser actualizados y facilita también el comando que se debe ejecutar para poder inicializar la actualización:

```shell
kubectl upgrade plan
```

Los pasos a seguir con toda esta información es:

1. **Actualizar kubeadm** a la siguiente versión de la versión que ya tenemos (nunca actualizar dos versiones o más por encima de la actual):

```shell
apt-get upgrade -t kubeadm=1.12.0-00
```

2. **Actualizar los componentes que lo requieran** con el siguiente comando:

```shell
kubectl upgrade apply v1.12.0
```

3. **Actualizar el kubelet del master node** en caso de tenerlo instalado, para ello actualizaremos desde linux con el siguiente comando:

```shell
apt-get upgrade -y kubelet=1.12.0-00
systemctl restart kubelet
```

4. **Actualizar los kubelets de los worker nodes** que, dependiendo de la estrategia que se quiera llevar a cabo, la realizaremos de un modo o de otro. 
 
	* Llevando a cabo la segunda estrategia, por poner un ejemplo, tendríamos que pasar todos los *pods* del primer nodo en el resto de *nodos*. 
	
	```shell
	kubectl drain node-01
	```
	
	 * Actualizamos el *nodo* que hemos dejado vacío:
	
	```shell
	apt-get upgrade -y kubeadm=1.12.0-00
	apt-get upgrade -y kubelet=1.12.0
	kubeadm upgrade node config --kubelet-version v1.12.0
	systemctl restart kubelet
	```
	
	* Desmarcamos el nodo como disponible nuevamente:
	
	```shell
	kubectl uncordon node-01
	```
	
	* Realizamos todos los pasos por cada *nodo*.



### **Docs**: [Upgrading kubeadm cluster](https://kubernetes.io/docs/tasks/administer-cluster/kubeadm/kubeadm-upgrade/)






#kubernetes #k8s #upgrade #cluster 