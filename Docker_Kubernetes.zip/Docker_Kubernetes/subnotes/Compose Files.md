El fichero de `docker-compose.yml` es una composición de servicios y la descripción de sus características, las cuales son todas aquellas que solemos describir a través de la línea de comandos cuando arrancamos un servidor.

### 1. Version
el primer campo de todo fichero es la **version**, en el cual se especifica la _versión de docker compose que se va a utilizar_.

### 2. Servicio
Es la cabecera de la _definición de cabeceras_ de cada uno de nuestros **servicios**. El nombre del servicio que incluyamos dentro puede ser cualquiera.

### 3. Características de servicio
Las características del servicio son muchas, se pueden encontrar más detalles de cada posibilidad en [Docker Docs - Compose file](https://docs.docker.com/compose/compose-file/).

Ejemplos de estas características son: **volume**, **image**, **environment**, **port**, ....

#### 3.1. Images
Podemos definir una imagen de modo que se descargue la maqueta desde docker hub:

```yaml
services: 
	mongodb:
		image: 'mongo'
```

Podemos construir una nueva imagen a través de un *Dockerfile* que ya tengamos. Para ello, en el servicio incluimos las siguientes opciones:

```yml
services:
	backend:
		build:
			context: ./path_to_dockerfile  # Ruta donde se encuentra el dockerfile
			dockerfile: dockerfile_name    # Nombre del archivo dockerfile creado
```

Podemos incluir argumentos en caso de que nuestro servicio los necesite:

```yml
services:
	backend:
		build:
			context: ./path_to_dockerfile
			dockerfile: dockerfile_name
			args:
				- NICKNAME: WARCKOR
```

#### 3.2. Volume
Definición de los volumenes, pudiendo ser [[Volume Containers#Anonymous Volumes]], [[Volume Containers#Named Volumes]] y [[Volume Containers#Bind Volumes]]. La definición en el fichero es muy parecida.

```yaml
# NAMED VOLUMES
services:
	mongodb:
		image: 'mongodb'
		volumes:
			- data:/data/db   # definicion de <Named_Volume>

# BIND VOLUMES
services:
	backend:
		build:
			context: ./path_to_dockerfile
			dockerfile: dockerfile_name
		volumes:
			- ./backend:/app  # <PATH_RELATIVO>:<PATH_APPLICACION>

# ANONYMOUS VOLUMES
services:
	backend:
		build:
			context: ./path_to_dockerfile
			dockerfile: dockerfile_name
		volumes:
			- /app/node_modules
```

Para terminar de definir los **named_volumes**, requerimos hacer referencia a los mismos una vez declarados todos los servicios, del siguiente modo:

```yml
services:
	mongodb:
		volumes:
			- data:/data/db
	backend:
	frontend:

volumes:
	data:
```

#### 3.3. Environment
Podemos definir **variables de entorno** dentro del servicio en caso de que la imagen lo requiera.

```yaml
services:
	image: 'mongodb'
	environment:
		MONGO_INITDB_ROOT_USERNAME: max
```

Podemos definir estas mismas **variables** dentro de un fichero, de modo que no tengamos que escribirlas dentro del propio *docker-compose file*.

El fichero debe terminar en `.env` y lo escribimos con el siguiente formato:

```
MONGO_INITDB_ROOT_USERNAME=max
MONGO_INITDB_ROOT_PASSWORD=password15
```

Con el fichero creado, podemos incluirlo en nuestro *docker-compose* así:

```yaml
services:
	image: 'mongodb'
	env_file:
		- ./<path>/<file>.env
```

#### 3.4. Network
Por defecto, *docker-compose* define una **red común** para todos los servicios que se encuentran dentro del *docker-compose file*, pero podemos definir nosotros una específica en caso de necesitarlo. PAra ello, en el fichero podemos declarar el nombre de la red que hayamos creado previamente en **Docker**.

```yaml
services:
	image: 'mognodb'
	networks:
		- my-net
```

#### 3.5. Port
Si el servicio tiene que exponer unos puertos, lo podemos definir del siguiente modo:

```yml
services:
	backend:
		build:
			context: ./path_to_dockerfile
			dockerfile: dockerfile_name
		ports:
			- '3000:80'     # <Puerto a exponer>:<puerto expuesto por el servicio>

```

#### 3.6. Depends on
Si uno de los servicios definidos en el **docker-compose.yaml** depende de otro servicio, podemos definirlo del siguiente modo:

```yml
services:
	backend:
		build:
			context: ./path_to_dockerfile
			dockerfile: dockerfile_name
		ports:
			- '3000:80'
		depends_on:
			- mongodb   # Nombre del servicio del que depende.
```

#### 3.7. Interactive mode
Para especificar en el **docker-compose.yaml** que necesitamos que el servicio tenga una conexión de entrada abierta, incluimos en el servicio la opcion `stdin_open`, que recibe un valor *boleano*, acompañado de la opción `tty` para especificar qué tipo de conexión de terminal queremos:

```yaml
services:
	frontend:
		build:
			context: ./path_to_dockerfile
			dockerfile: dockerfile_name
		ports:
			- '3001:443'
		stdin_open: true   # Equivamente a -it en Docker
		tty: true
```

### 4. Ejemplo

```yaml
version: "3.8"
services:
	mongodb:
		image: 'mongo'
		volumes:
			- data:/data/db
		environment:
			MONGO_INITDB_ROOT_USERNAME: max
		env_file:
			- ./<path>/<file>.env
		networks:
			- my-net
	backend:
		build:
			context: ./path_to_dockerfile
			dockerfile: dockerfile_name
			args:
				- NICKNAME: WARCKOR
		ports:
			- '3000:80'
		volumes:
			- ./backend:/app
			- /app/node_modules
		depend_on:
			- mongodb
	frontend:
		build:
			context: ./path_to_dockerfile
			dockerfile: dockerfile_name
		ports:
			- '3001:443'
volumes:
	data:
```








#docker #docker-compose #services