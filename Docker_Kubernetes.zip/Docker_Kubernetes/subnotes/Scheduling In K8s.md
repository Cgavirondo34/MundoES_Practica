Esta tarea dentro de *Kubernetes* tiene la función de asignar los *Pods* a un nodo de los que existen. Si el *Pod* no tiene definido un nodo específico al que pertenezca, el **Scheduler** se ocupa de asignar uno automáticamente según las características definidas del *Pod*.

Esto mismo se puede asignar manualmente dentro del `YAML` de configuración, incluyendo el campo `nodeName` y especificando el nodo donde queremos que se encuentre nuestro *Pod*.

```yaml
apiVersion: v1
kind: Pod
metadata: 
	name: nginx
	labels:
		name: nginx
spec:
	containers:
		- name: nginx
		  image: nginx
		  ports:
			  - containerPort: 8080
	nodeName: node02
```

Podemos revisar si el *Scheduler* se está ejecutando en el **namespace kube-system**. Para ello, ejecutamos el siguiente comando para ver los *Pods* del sistema de *Kubernetes* y comprobar si el *Scheduler* se encuentra levantado:

```shell
kubectl get pods --namespace kube-system
kubectl get pods -n kube-system
```















#kubernetes #k8s #declarative #scheduler #pod #node