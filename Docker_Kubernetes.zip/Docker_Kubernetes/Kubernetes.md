### 1. Consola Kubernetes: [[Imperative Approach]]

### 2. Kubernetes YAML: [[Declarative Approach]]

### 3. Volumenes Kubernetes: [[Volumes & Config]]

### 4. Variables de Entorno Kubernetes: [[Environment Variables & Config Maps]]

### 5. Redes en Kubernetes: [[Kubernetes & Networking]]

### 6. Comandos Kubernetes: [[Console Commands]]

### 7. Kubernetes Scheduler: [[Scheduling In K8s]]

### 8. Límites y Tolerancias: [[Taints And Tolerations]]

### 9. Selectores de Nodo: [[Nodes Selectors]]

### 10. Afinidad de Nodo: [[Node Affinity]]

### 11. Límite de Recursos: [[Limit Resources]]

### 12. Daemon Sets en Kubernetes: [[Daemon Sets]]

### 13. Pods Estáticos: [[Static Pods]]

### 14. Multiples Schedulers: [[Multiple Schedulers]]

### 15. Monitorizar Kubernetes: [[Monitoring Kubernetes]]

### 16. Rollout y Rollback: [[Rollout And Rollback]]

### 17. Comandos y Argumentos: [[Commands And Arguments]]

### 18. Variables De Entorno: [[Environment Variables]]

### 19. Multi-Contenedores: [[Multi Container PODs]]

### 20. Upgrade y Versiones: [[Upgrades And Versions]]

### 21. Backup y Restauración: [[Backups And Restores]]

### 22. Seguridad: [[Security]]

### 23. Almacenamiento: [[Storage k8s]]

### 24. Redes: [[Networking k8s]]







#kubernetes #k8s